import asyncio
import time
import json
import os
import asyncio
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import silhouette_score
from sklearn.cluster import KMeans
from sklearn.model_selection import GridSearchCV
import jieba
from collections import defaultdict, deque
import logging
import re
import random
import sqlite3
import gensim
from gensim.models import KeyedVectors
from gensim.models.word2vec import Word2Vec

# 设置日志
logger = logging.getLogger('Ben_learning_chat.enhanced_learning')

# 自定义分词函数，移到全局作用域以支持pickle序列化
def tokenize_jieba(text):
    """使用jieba进行中文分词"""
    return list(jieba.cut_for_search(text))

class EnhancedTrainingSystem:
    """增强的训练系统，负责自主训练和效果评估"""
    def __init__(self, db_path: str, config):
        self.db_path = db_path
        self.config = config
        
        # 自主训练相关配置
        self.last_training_time = 0
        self.message_count_since_last_training = 0
        self.training_scheduler = None
        
        # 效果评估指标
        self.performance_metrics = {
            'reply_relevance': [],  # 回复相关性评分
            'conversation_coherence': [],  # 对话连贯性评分
            'user_satisfaction': [],  # 用户满意度（基于回复后的互动）
            'training_efficiency': [],  # 训练效率（时间/质量）
            'model_accuracy': [],  # 模型准确率指标
            'personalization_score': [],  # 个性化程度评分
            'context_awareness': [],  # 上下文感知能力评分
            'logical_consistency': []  # 逻辑一致性评分
        }
        
        # 高级模型存储
        self.vectorizer = None
        self.word_embeddings = None
        self.cluster_model = None
        self.optimization_history = []
        self.model_versions = [{"version": self.config.model_version, "created_at": datetime.now().isoformat(), "message_count": 0, "status": "active"}]  # 模型版本历史
        
        # 消息和训练数据缓存
        self.message_cache = []
        self.training_data_cache = []
        self.high_quality_messages = []
        self.recent_replies = defaultdict(lambda: deque(maxlen=100))  # 最近回复缓存
        
        # 多轮对话上下文存储
        self.context_memory = defaultdict(lambda: deque(maxlen=self.config.context_window_size))
        
        # 用户个性化数据
        self.user_profiles = {}
        self.user_interaction_history = defaultdict(lambda: deque(maxlen=50))  # 用户互动历史
        
        # 模型调参配置 - 增加更多参数选项
        self.tuning_params = {
            'tfidf_max_features': [5000, 10000, 20000],
            'tfidf_ngram_range': [1, 2, 3],
            'tfidf_min_df': [2, 3, 5],
            'tfidf_max_df': [0.8, 0.9, 1.0],
            'cluster_max_clusters': [5, 10, 20]
        }
        
        # 添加查询缓存机制
        self.query_cache = {}
        self.cache_size_limit = getattr(config, 'query_cache_size', 100)
        
        # 逻辑关系模式库
        self.logical_patterns = {
            '因果关系': [
                r'(因为|由于|鉴于).*?(所以|因此|故此|因而|于是)',
                r'(所以|因此|故此|因而|于是).*?(因为|由于|鉴于)',
                r'(导致|造成|使得|引起).*?结果'
            ],
            '条件关系': [
                r'(如果|假如|假设|要是|若).*?(就|那么|则)',
                r'(只有|除非).*?(才|否则)',
                r'(只要).*?(就|便)'
            ],
            '转折关系': [
                r'(虽然|尽管|虽说).*?(但是|可是|然而|不过|却)',
                r'(但是|可是|然而|不过|却).*?(虽然|尽管|虽说)'
            ],
            '递进关系': [
                r'(不仅|不但).*?(而且|并且|还|也)',
                r'(而且|并且|还|也).*?(更|甚至)'
            ],
            '并列关系': [
                r'(既).*?(又|也)',
                r'(一边|一面).*?(一边|一面)',
                r'(和|与|以及|并且|同时)'
            ]
        }
        
        # 逻辑关系词汇库
        self.logic_relations = {
            '因果关系': {
                '因为': ['所以才会这样', '因此出现了这种情况', '导致了这个结果'],
                '由于': ['所以会这样', '因此才会发生', '导致了这种结果'],
                '导致': ['结果就是', '从而使得', '因此造成了']
            },
            '条件关系': {
                '如果': ['那么就应该', '则会导致', '就需要'],
                '要是': ['那么就', '就会', '则应该'],
                '只有': ['才能够', '才能实现', '才会']
            },
            '转折关系': {
                '虽然': ['但是', '可是', '然而'],
                '尽管': ['但是', '可是', '不过'],
                '但是': ['不过', '然而', '可是']
            },
            '递进关系': {
                '不仅': ['而且', '并且', '还'],
                '不但': ['而且', '并且', '还'],
                '而且': ['还', '甚至', '更进一步']
            },
            '并列关系': {
                '同时': ['也', '并且', '此外'],
                '以及': ['还有', '同时', '另外'],
                '和': ['与', '以及', '还有']
            }
        }
        
        # 初始化评估数据库
        self._init_metrics_db()
        
        # 尝试加载已保存的模型
        self._load_model_state()
        
        # 初始化逻辑分析器
        self.semantic_analyzer = AdvancedSemanticAnalyzer()
    
    def _init_metrics_db(self):
        """初始化性能指标数据库"""
        import sqlite3
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                # 创建性能指标表
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS performance_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER,
                    metric_type TEXT,
                    value REAL,
                    details TEXT
                )
                ''')
                # 创建训练历史表
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS training_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER,
                    message_count INTEGER,
                    duration REAL,
                    model_version TEXT,
                    status TEXT,
                    metrics TEXT
                )
                ''')
                # 创建用户反馈表
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS user_feedback (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp INTEGER,
                    user_id TEXT,
                    message TEXT,
                    reply TEXT,
                    feedback_type TEXT,
                    feedback_score REAL,
                    feedback_content TEXT
                )
                ''')
                # 创建回复权重表
                cursor.execute('''
                CREATE TABLE IF NOT EXISTS reply_weights (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    message TEXT,
                    reply TEXT,
                    weight REAL,
                    usage_count INTEGER,
                    last_used INTEGER
                )
                ''')
                conn.commit()
        except Exception as e:
            logger.error(f"初始化指标数据库失败: {e}")
    
    async def start_auto_training(self):
        """启动自动训练调度器"""
        if self.training_scheduler and not self.training_scheduler.done():
            logger.warning("自动训练调度器已经在运行")
            return
            
        logger.info("启动自动训练调度器")
        self.training_scheduler = asyncio.create_task(self._auto_training_loop())
    
    async def stop_auto_training(self):
        """停止自动训练调度器"""
        if self.training_scheduler and not self.training_scheduler.done():
            self.training_scheduler.cancel()
            try:
                await self.training_scheduler
            except asyncio.CancelledError:
                logger.info("自动训练调度器已停止")
            except Exception as e:
                logger.error(f"停止训练调度器时出错: {e}")
        else:
            logger.info("自动训练调度器未运行")
    
    async def _auto_training_loop(self):
        """自动训练主循环 - 智能增强版"""
        while True:
            try:
                # 获取当前性能指标
                metrics_summary = self._get_current_metrics_summary()
                
                # 智能调整检查间隔
                check_interval = self._adjust_check_interval(metrics_summary)
                
                # 检查是否需要训练，考虑多种触发条件
                if await self._should_train():
                    logger.info("触发自动训练")
                    await self.perform_training()
                # 如果性能指标下降，即使不满足常规训练条件也触发训练
                elif self._should_train_on_performance_drop(metrics_summary):
                    logger.info("检测到性能下降，触发紧急训练")
                    await self.perform_training()
                # 基于用户反馈触发训练
                elif self._should_train_on_feedback():
                    logger.info("检测到负面用户反馈，触发针对性训练")
                    await self.perform_training()
                # 基于模型老化程度触发训练
                elif self._should_train_on_model_age():
                    logger.info("模型老化，触发定期训练")
                    await self.perform_training()
                    
                # 等待下次检查
                await asyncio.sleep(check_interval)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logger.error(f"自动训练循环出错: {e}")
                # 发生错误后等待更长时间再尝试
                await asyncio.sleep(max(60, self.config.auto_training_check_interval))
    
    def _adjust_check_interval(self, metrics_summary: Dict[str, float]) -> float:
        """根据当前性能指标和模型状态动态调整检查间隔"""
        base_interval = self.config.auto_training_check_interval
        
        # 获取模型整体状态
        model_status = metrics_summary.get('model_status', 'average')
        overall_performance = metrics_summary.get('overall_performance', 0.7)
        
        # 根据综合性能调整检查间隔
        if model_status == 'excellent' and overall_performance >= 0.85:
            # 性能优秀，延长检查间隔
            return min(base_interval * 2.0, self.config.auto_training_check_interval_max)
        elif model_status == 'good' and overall_performance >= 0.7:
            # 性能良好，适当延长检查间隔
            return min(base_interval * 1.5, self.config.auto_training_check_interval_max)
        elif model_status == 'poor' or overall_performance < 0.5:
            # 性能较差，缩短检查间隔
            return max(base_interval * 0.3, self.config.auto_training_check_interval_min)
        elif model_status == 'average':
            # 性能一般，根据关键指标微调
            if (metrics_summary.get('reply_relevance_avg', 0) < 0.65 or 
                metrics_summary.get('logical_consistency_avg', 0) < 0.7):
                return max(base_interval * 0.7, self.config.auto_training_check_interval_min)
        
        # 检查趋势
        trend_direction = metrics_summary.get('reply_relevance_trend_direction', 'stable')
        if trend_direction == 'improving':
            # 性能在提升，适当延长检查间隔
            return min(base_interval * 1.2, self.config.auto_training_check_interval_max)
        elif trend_direction == 'declining':
            # 性能在下降，缩短检查间隔
            return max(base_interval * 0.6, self.config.auto_training_check_interval_min)
        
        # 考虑用户反馈情况
        negative_feedback_ratio = metrics_summary.get('negative_feedback_ratio', 0)
        if negative_feedback_ratio > 0.3:
            # 负面反馈较多，缩短检查间隔
            return max(base_interval * 0.5, self.config.auto_training_check_interval_min)
        
        return base_interval
    
    def _should_train_on_performance_drop(self, metrics_summary: Dict[str, float]) -> bool:
        """检测性能下降并触发紧急训练"""
        # 如果没有足够的历史数据，不触发
        if len(self.performance_metrics['reply_relevance']) < 5:
            return False
        
        # 检查关键指标是否下降超过阈值
        recent_relevance = np.mean(self.performance_metrics['reply_relevance'][-5:])
        earlier_relevance = np.mean(self.performance_metrics['reply_relevance'][-10:-5])
        
        # 如果性能下降超过15%，触发紧急训练
        if earlier_relevance - recent_relevance > 0.15:
            logger.warning(f"检测到回复相关性下降: {earlier_relevance:.2f} -> {recent_relevance:.2f}")
            return True
        
        # 检查逻辑一致性
        if 'logical_consistency' in self.performance_metrics and len(self.performance_metrics['logical_consistency']) >= 5:
            recent_consistency = np.mean(self.performance_metrics['logical_consistency'][-5:])
            # 如果逻辑一致性低于阈值，触发训练
            if recent_consistency < 0.7:
                logger.warning(f"逻辑一致性低于阈值: {recent_consistency:.2f}")
                return True
        
        # 检查上下文感知能力
        if 'context_awareness' in self.performance_metrics and len(self.performance_metrics['context_awareness']) >= 5:
            recent_context_awareness = np.mean(self.performance_metrics['context_awareness'][-5:])
            # 如果上下文感知能力低于阈值，触发训练
            if recent_context_awareness < 0.65:
                logger.warning(f"上下文感知能力低于阈值: {recent_context_awareness:.2f}")
                return True
        
        return False
        
    def _should_train_on_feedback(self) -> bool:
        """基于用户反馈触发训练"""
        import sqlite3
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 检查最近24小时内的负面反馈数量
                one_day_ago = int(time.time()) - 86400
                cursor.execute(
                    '''SELECT COUNT(*) FROM user_feedback 
                    WHERE timestamp >= ? AND feedback_score <= 2.0''',
                    (one_day_ago,)
                )
                negative_feedback_count = cursor.fetchone()[0]
                
                # 检查最近24小时内的总反馈数量
                cursor.execute(
                    '''SELECT COUNT(*) FROM user_feedback 
                    WHERE timestamp >= ?''',
                    (one_day_ago,)
                )
                total_feedback_count = cursor.fetchone()[0]
                
                # 如果负面反馈比例超过30%，或者负面反馈数量超过5条，触发训练
                if total_feedback_count > 0:
                    negative_ratio = negative_feedback_count / total_feedback_count
                    if negative_ratio > 0.3 or negative_feedback_count >= 5:
                        logger.info(f"负面反馈比例过高: {negative_ratio:.2%} ({negative_feedback_count}/{total_feedback_count})")
                        return True
            
            return False
        except Exception as e:
            logger.error(f"检查反馈触发条件失败: {e}")
            return False
            
    def _should_train_on_model_age(self) -> bool:
        """基于模型老化程度触发训练"""
        # 检查模型是否长时间未更新
        max_model_age = 7 * 24 * 3600  # 默认7天
        if hasattr(self.config, 'max_model_age'):
            max_model_age = self.config.max_model_age
            
        # 检查当前模型的创建时间
        if self.model_versions and len(self.model_versions) > 0:
            active_model = next((v for v in self.model_versions if v['status'] == 'active'), None)
            if active_model:
                created_time = datetime.fromisoformat(active_model['created_at']).timestamp()
                model_age = time.time() - created_time
                
                if model_age > max_model_age:
                    logger.info(f"模型已老化 ({model_age/86400:.1f}天)，触发训练")
                    return True
        
        return False
    
    async def _should_train(self) -> bool:
        """判断是否应该进行训练"""
        current_time = time.time()
        
        # 检查时间间隔
        time_condition = current_time - self.last_training_time >= self.config.auto_training_interval
        
        # 检查消息数量
        message_condition = self.message_count_since_last_training >= self.config.auto_training_min_messages
        
        return time_condition or message_condition
    
    async def perform_training(self):
        """执行训练过程"""
        import sqlite3
        
        start_time = time.time()
        start_time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        logger.info(f"开始训练AI模型，时间: {start_time_str}")
        
        # 保存当前版本作为备份
        current_version = self.config.model_version
        logger.info(f"训练前备份当前版本: {current_version}")
        self._save_model_state(current_version)
        
        try:
            # 获取训练数据
            messages = []
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT message FROM chat_logs WHERE quality_score >= ? ORDER BY RANDOM() LIMIT ?",
                    (self.config.message_quality_threshold, self.config.training_max_messages)
                )
                messages = [row[0] for row in cursor.fetchall()]
            
            if not messages:
                logger.warning("没有足够的高质量消息用于训练")
                return
            
            message_count = len(messages)
            logger.info(f"使用 {message_count} 条消息进行训练")
            
            # 执行高级训练
            await self._advanced_training(messages)
            
            # 更新版本号
            old_version = self.config.model_version
            self._update_model_version()
            new_version = self.config.model_version
            
            # 记录训练完成时间
            duration = time.time() - start_time
            self.last_training_time = time.time()
            self.message_count_since_last_training = 0
            
            # 保存新版本
            logger.info(f"训练完成，保存新版本: {new_version}")
            self._save_model_state(new_version)
            
            # 保存训练历史
            metrics_summary = self._get_current_metrics_summary()
            self._save_training_history(message_count, duration, metrics_summary)
            
            logger.info(f"AI模型训练完成，耗时: {duration:.2f}秒，版本: {new_version}")
        except Exception as e:
            logger.error(f"训练过程出错: {e}")
            # 尝试回滚到训练前的版本
            logger.info(f"训练失败，尝试回滚到版本: {current_version}")
            self._load_model_state(current_version)
            
            # 记录失败状态
            duration = time.time() - start_time
            self._save_training_history(0, duration, {}, status="failed", error=str(e))
    
    async def _advanced_training(self, messages: List[str]):
        """增强版高级训练算法，包含逻辑推理能力提升"""
        try:
            # 1. 执行数据预处理和质量增强
            logger.info(f"开始预处理 {len(messages)} 条训练消息")
            processed_messages, logic_enhanced_count = self._preprocess_and_enhance_training_data(messages)
            logger.info(f"预处理完成，其中 {logic_enhanced_count} 条消息包含逻辑关系增强")
            
            # 2. 执行增强版自动参数优化
            if self.config.auto_tuning_enabled and (self.message_count_since_last_training > self.config.tuning_min_messages or 
                                                  time.time() - self.last_training_time > self.config.tuning_interval):
                tuned_params = await self._auto_tune_parameters(processed_messages)
                logger.info(f"增强版自动参数优化完成，最佳参数: {tuned_params}")
                
                # 更新配置
                for param, value in tuned_params.items():
                    setattr(self.config, param, value)
                
                # 参数优化后进行逻辑一致性验证
                await self._validate_logical_consistency(processed_messages, tuned_params)
            
            # 3. 训练增强版TF-IDF向量器（优化逻辑关系处理）
            self._train_enhanced_tfidf_with_logic(processed_messages)
            
            # 4. 训练增强版对话聚类模型
            self._train_enhanced_clustering_model(processed_messages)
            
            # 5. 训练增强版用户个性化模型
            await self._train_enhanced_personalization_model()
            
            # 6. 训练逻辑关系识别模型
            await self._train_logic_relation_model(processed_messages)
            
            # 7. 保存完整的训练结果
            self._save_complete_model_state()
            
            # 8. 执行智能缓存清理
            self._smart_cleanup_caches()
            
            # 9. 更新模型版本和迭代计数器
            self._update_model_version()
            
            logger.info(f"高级训练成功完成，模型版本: {self.config.model_version}")
        except Exception as e:
            logger.error(f"高级训练失败: {e}")
            # 记录失败原因并进行自我修复尝试
            self._attempt_self_recovery(e)
            raise
            
    def _preprocess_and_enhance_training_data(self, messages: List[str]) -> Tuple[List[str], int]:
        """预处理训练数据并增强逻辑关系表达"""
        processed = []
        logic_enhanced_count = 0
        
        # 统计各种逻辑关系在消息中的出现频率
        logic_relation_stats = defaultdict(int)
        
        for message in messages:
            if not message or not isinstance(message, str):
                continue
                
            # 清理消息
            clean_message = self._clean_message(message)
            if not clean_message:
                continue
                
            # 增强逻辑关系表达
            enhanced_message, enhanced = self._enhance_logical_expressions(clean_message)
            if enhanced:
                logic_enhanced_count += 1
                
            # 检查消息质量
            quality_score = self._evaluate_content_quality(enhanced_message)
            if quality_score < getattr(self.config, 'min_training_quality', 0.5):
                continue
                
            processed.append(enhanced_message)
            
            # 更新逻辑关系统计
            for relation_type, words in self.logic_relations.items():
                for word in words:
                    if word in enhanced_message:
                        logic_relation_stats[relation_type] += 1
            
        # 记录逻辑关系统计
        if logic_relation_stats:
            logger.info(f"训练数据中的逻辑关系分布: {dict(logic_relation_stats)}")
            
        return processed, logic_enhanced_count
        
    def _clean_message(self, message: str) -> str:
        """清理消息文本"""
        # 移除CQ码和特殊标记
        cleaned = re.sub(r'\[CQ:.*?\]', '', message)
        # 移除多余空白字符
        cleaned = ' '.join(cleaned.split())
        # 移除链接和邮箱
        cleaned = re.sub(r'https?://\S+|www\.\S+|\S+@\S+\.\S+', '', cleaned)
        # 移除多余的标点符号
        cleaned = re.sub(r'([,.?!，。？！])\1+', '\1', cleaned)
        
        return cleaned.strip()
        
    def _enhance_logical_expressions(self, message: str) -> Tuple[str, bool]:
        """增强消息中的逻辑关系表达"""
        original_message = message
        enhanced = False
        
        # 检查并增强因果关系表达
        for cause_word, effect_phrases in self.logic_relations.get('因果关系', {}).items():
            if cause_word in message:
                # 简单增强 - 在实际应用中可以实现更复杂的逻辑关系增强
                if random.random() < 0.3:  # 30%的概率进行增强
                    effect_phrase = random.choice(effect_phrases)
                    if effect_phrase not in message:
                        message = f"{message}，{effect_phrase}"
                        enhanced = True
        
        # 检查并增强条件关系表达
        for if_word, then_phrases in self.logic_relations.get('条件关系', {}).items():
            if if_word in message and not any(phrase in message for phrase in then_phrases):
                if random.random() < 0.25:  # 25%的概率进行增强
                    then_phrase = random.choice(then_phrases)
                    message = f"{message}，{then_phrase}"
                    enhanced = True
        
        return message, enhanced
        
    async def _validate_logical_consistency(self, messages: List[str], tuned_params: Dict[str, Any]):
        """验证参数优化后的逻辑一致性"""
        try:
            logger.info("开始验证参数逻辑一致性")
            
            # 样本测试消息，包含各种逻辑关系
            test_messages = [
                "因为今天下雨，所以我没有去公园。",
                "如果你明天有空，我们可以一起去看电影。",
                "虽然天气很热，但是我们还是坚持完成了任务。",
                "他不仅学习好，而且体育也很出色。",
                "我喜欢吃苹果，同时也喜欢吃香蕉。"
            ]
            
            # 创建临时向量器测试逻辑一致性
            temp_vectorizer = TfidfVectorizer(
                tokenizer=lambda x: list(jieba.cut_for_search(x)),
                max_features=tuned_params.get('tfidf_max_features', 10000),
                ngram_range=(1, tuned_params.get('tfidf_ngram_range', 2)),
                min_df=tuned_params.get('tfidf_min_df', 0.001),
                max_df=tuned_params.get('tfidf_max_df', 0.95)
            )
            
            # 混合训练消息和测试消息进行训练
            combined_test = messages[:500] + test_messages
            temp_vectorizer.fit(combined_test)
            
            # 评估逻辑一致性
            logic_score = self._evaluate_logic_consistency(temp_vectorizer)
            
            logger.info(f"参数逻辑一致性评分: {logic_score:.4f}")
            
            # 如果逻辑一致性评分过低，调整参数
            if logic_score < 0.6:
                logger.warning(f"逻辑一致性评分过低，尝试调整参数")
                # 增加n-gram范围以捕获更多逻辑关系
                if 'tfidf_ngram_range' in tuned_params:
                    tuned_params['tfidf_ngram_range'] = min(3, tuned_params['tfidf_ngram_range'] + 1)
                # 降低min_df以保留更多逻辑关系词
                if 'tfidf_min_df' in tuned_params:
                    tuned_params['tfidf_min_df'] = max(0.0001, tuned_params['tfidf_min_df'] * 0.5)
                
                logger.info(f"已调整参数以提高逻辑一致性: {tuned_params}")
            
        except Exception as e:
            logger.error(f"逻辑一致性验证失败: {e}")
            
    def _train_enhanced_tfidf_with_logic(self, messages: List[str]):
        """训练增强版TF-IDF向量器，特别优化逻辑关系处理"""
        # 自定义分词函数，特别处理逻辑关系词
        def enhanced_tokenize(text):
            tokens = list(jieba.cut_for_search(text))
            # 合并逻辑关系词（简单实现）
            logic_tokens = []
            i = 0
            while i < len(tokens):
                # 检查双词逻辑关系
                if i < len(tokens) - 1:
                    two_word = ''.join(tokens[i:i+2])
                    for relation_type, words in self.logic_relations.items():
                        if two_word in words:
                            logic_tokens.append(two_word)
                            i += 2
                            break
                    else:
                        logic_tokens.append(tokens[i])
                        i += 1
                else:
                    logic_tokens.append(tokens[i])
                    i += 1
            return logic_tokens
        
        # 配置增强的TF-IDF向量器，优化逻辑关系处理
        self.vectorizer = TfidfVectorizer(
            tokenizer=enhanced_tokenize,
            max_features=self.config.tfidf_max_features,
            min_df=self.config.tfidf_min_df,
            max_df=self.config.tfidf_max_df,
            ngram_range=(1, self.config.tfidf_ngram_range),
            use_idf=True,
            smooth_idf=True,
            sublinear_tf=True,
            # 增加逻辑关系词的权重
            vocabulary=self._build_enhanced_vocabulary(messages)
        )
        
        # 训练向量器
        self.vectorizer.fit(messages)
        
        # 评估逻辑关系词覆盖率
        logic_coverage = self._evaluate_logic_relation_coverage()
        
        logger.info(f"TF-IDF向量器训练完成，词汇表大小: {len(self.vectorizer.vocabulary_)}, 逻辑关系词覆盖率: {logic_coverage:.2%}")
        
        # 记录性能指标
        self.record_metric('vectorizer_quality', min(logic_coverage, 1.0), {
            'vocab_size': len(self.vectorizer.vocabulary_),
            'logic_coverage': logic_coverage
        })
        
    def _build_enhanced_vocabulary(self, messages: List[str]) -> Optional[Dict[str, int]]:
        """构建增强的词汇表，特别强调逻辑关系词"""
        try:
            # 收集所有逻辑关系词
            logic_words = set()
            for relation_type, words in self.logic_relations.items():
                logic_words.update(words)
            
            # 简单实现：不直接干预词汇表构建，让TF-IDF算法自动处理
            # 在实际应用中可以实现更复杂的词汇表增强策略
            return None  # 使用None表示让向量器自己构建词汇表
        except Exception as e:
            logger.error(f"构建增强词汇表失败: {e}")
            return None
            
    def _evaluate_logic_relation_coverage(self) -> float:
        """评估向量器词汇表中逻辑关系词的覆盖率"""
        if not self.vectorizer or not hasattr(self.vectorizer, 'vocabulary_'):
            return 0
            
        # 统计逻辑关系词覆盖率
        total_logic_words = 0
        covered_logic_words = 0
        
        for relation_type, words in self.logic_relations.items():
            total_logic_words += len(words)
            for word in words:
                if word in self.vectorizer.vocabulary_:
                    covered_logic_words += 1
                    
        return covered_logic_words / total_logic_words if total_logic_words > 0 else 0
        
    def _train_enhanced_clustering_model(self, messages: List[str]):
        """训练增强版对话聚类模型"""
        if not self.vectorizer or len(messages) < self.config.cluster_min_samples:
            logger.warning("跳过聚类模型训练，条件不满足")
            return
        
        # 将消息转换为向量
        message_vectors = self.vectorizer.transform(messages)
        
        # 确定最佳聚类数量（基于轮廓系数）
        best_n_clusters = getattr(self.config, 'n_clusters', 20)
        if hasattr(self, 'optimization_history') and self.optimization_history:
            latest_optimization = self.optimization_history[-1]
            if 'n_clusters' in latest_optimization.get('params', {}):
                best_n_clusters = latest_optimization['params']['n_clusters']
        
        # 训练增强的K-means模型
        self.cluster_model = KMeans(
            n_clusters=best_n_clusters,
            random_state=42,
            n_init=20,  # 增加初始化次数以获得更稳定的结果
            max_iter=300
        )
        self.cluster_model.fit(message_vectors)
        
        # 评估聚类质量
        try:
            silhouette_avg = silhouette_score(message_vectors, self.cluster_model.labels_)
            logger.info(f"增强版聚类模型训练完成，聚类数量: {best_n_clusters}, 轮廓系数: {silhouette_avg:.4f}")
            
            # 记录聚类性能
            self.record_metric('clustering_quality', silhouette_avg, {
                'n_clusters': best_n_clusters
            })
        except Exception as e:
            logger.warning(f"聚类质量评估失败: {e}")
            
    async def _train_enhanced_personalization_model(self):
        """训练增强版用户个性化模型"""
        try:
            # 复用原有的训练方法，但增加逻辑关系处理
            await self._train_personalization_model()
            
            logger.info("增强版用户个性化模型训练完成")
        except Exception as e:
            logger.error(f"增强版用户个性化模型训练失败: {e}")
            
    async def _train_logic_relation_model(self, messages: List[str]):
        """训练专门的逻辑关系识别模型"""
        try:
            logger.info("开始训练逻辑关系识别模型")
            
            # 简单实现：标记包含逻辑关系的消息
            logic_relation_messages = []
            for message in messages:
                for relation_type, words in self.logic_relations.items():
                    if any(word in message for word in words):
                        logic_relation_messages.append(message)
                        break
            
            # 记录逻辑关系模型训练信息
            logic_message_count = len(logic_relation_messages)
            total_message_count = len(messages)
            logic_ratio = logic_message_count / total_message_count if total_message_count > 0 else 0
            
            logger.info(f"逻辑关系模型训练完成，包含逻辑关系的消息: {logic_message_count}/{total_message_count} ({logic_ratio:.2%})")
            
            # 记录逻辑关系模型性能
            self.record_metric('logic_model_quality', logic_ratio, {
                'logic_message_count': logic_message_count,
                'total_message_count': total_message_count
            })
            
            # 在实际应用中，可以实现更复杂的逻辑关系识别模型
        except Exception as e:
            logger.error(f"逻辑关系模型训练失败: {e}")
            
    def _save_complete_model_state(self):
        """保存完整的模型状态，包括逻辑关系模型"""
        # 调用原有的保存方法
        self._save_model_state()
        
        # 保存逻辑关系数据
        try:
            model_dir = os.path.join(os.path.dirname(self.db_path), 'models')
            logic_model_path = os.path.join(model_dir, 'logic_relation_data.json')
            
            # 保存逻辑关系统计信息
            logic_data = {
                'logic_relations': self.logic_relations,
                'last_updated': time.time(),
                'model_version': self.config.model_version
            }
            
            with open(logic_model_path, 'w', encoding='utf-8') as f:
                json.dump(logic_data, f, ensure_ascii=False, indent=2)
                
            logger.info(f"逻辑关系数据已保存到: {logic_model_path}")
        except Exception as e:
            logger.error(f"保存逻辑关系数据失败: {e}")
            
    def _smart_cleanup_caches(self):
        """智能清理缓存，保留重要的训练数据"""
        # 调用原有的清理方法
        self._cleanup_old_caches()
        
        # 智能缓存管理：保留高质量的逻辑关系消息
        try:
            # 按逻辑关系丰富度排序并保留高质量消息
            if hasattr(self, 'high_quality_messages') and self.high_quality_messages:
                # 计算每条消息的逻辑关系丰富度
                logic_enriched_messages = []
                for msg in self.high_quality_messages:
                    logic_count = 0
                    for relation_type, words in self.logic_relations.items():
                        logic_count += sum(1 for word in words if word in msg)
                    logic_enriched_messages.append((msg, logic_count))
                
                # 按逻辑关系丰富度排序
                logic_enriched_messages.sort(key=lambda x: x[1], reverse=True)
                
                # 保留逻辑关系最丰富的前50%消息
                keep_count = max(100, len(logic_enriched_messages) // 2)
                self.high_quality_messages = [msg for msg, _ in logic_enriched_messages[:keep_count]]
                
                logger.info(f"智能缓存清理完成，保留了 {keep_count} 条高质量逻辑关系消息")
        except Exception as e:
            logger.error(f"智能缓存清理失败: {e}")
            
    def _update_model_version(self):
        """更新模型版本号"""
        try:
            # 增加模型小版本号
            current_version = self.config.model_version
            if isinstance(current_version, str):
                # 简单版本号递增逻辑
                parts = current_version.split('.')
                if len(parts) >= 3:
                    patch_version = int(parts[2]) + 1
                    new_version = f"{parts[0]}.{parts[1]}.{patch_version}"
                else:
                    new_version = f"{current_version}.1"
            else:
                new_version = current_version + 0.01
            
            # 更新当前版本状态
            for v in self.model_versions:
                if v["version"] == current_version:
                    v["status"] = "inactive"
                    v["message_count"] = self.message_count_since_last_training
            
            # 创建新版本记录
            self.model_versions.append({
                "version": new_version,
                "created_at": datetime.now().isoformat(),
                "message_count": 0,
                "status": "active"
            })
            
            # 更新版本号
            self.config.model_version = new_version
            
            # 记录版本更新
            logger.info(f"模型版本已更新为: {self.config.model_version}")
            
            # 在实际应用中，可以实现更复杂的版本控制逻辑
        except Exception as e:
            logger.error(f"更新模型版本失败: {e}")
            
    def _attempt_self_recovery(self, error: Exception):
        """训练失败时尝试自我修复"""
        try:
            logger.info("开始尝试自我修复")
            
            # 记录失败信息
            failure_info = {
                'timestamp': time.time(),
                'error_type': type(error).__name__,
                'error_message': str(error),
                'model_version': self.config.model_version
            }
            
            # 尝试加载上一个成功的模型状态
            if hasattr(self, '_load_model_state'):
                success = self._load_model_state()
                if success:
                    logger.info("成功加载上一个模型状态")
                else:
                    # 如果无法加载上一个模型，重置关键组件
                    logger.warning("无法加载上一个模型状态，重置关键组件")
                    self.vectorizer = None
                    self.cluster_model = None
                    
            # 降低训练复杂度以避免再次失败
            if hasattr(self.config, 'tfidf_max_features'):
                self.config.tfidf_max_features = max(5000, int(self.config.tfidf_max_features * 0.8))
            
            logger.info("自我修复尝试完成")
            
        except Exception as e:
            logger.error(f"自我修复失败: {e}")
    
    def _train_enhanced_tfidf(self, messages: List[str]):
        """训练增强版TF-IDF向量器"""
        # 配置增强的TF-IDF向量器，使用全局tokenize_jieba函数
        self.vectorizer = TfidfVectorizer(
            tokenizer=tokenize_jieba,
            token_pattern=None,  # 显式设置为None避免警告
            max_features=self.config.tfidf_max_features,
            min_df=self.config.tfidf_min_df,
            max_df=self.config.tfidf_max_df,
            ngram_range=(1, self.config.tfidf_ngram_range),
            use_idf=True,
            smooth_idf=True,
            sublinear_tf=True
        )
        
        # 训练向量器
        self.vectorizer.fit(messages)
        logger.info(f"TF-IDF向量器训练完成，词汇表大小: {len(self.vectorizer.vocabulary_)}")
    
    def _train_clustering_model(self, messages: List[str]):
        """训练对话聚类模型"""
        if not self.vectorizer or len(messages) < self.config.cluster_min_samples:
            logger.warning("跳过聚类模型训练，条件不满足")
            return
        
        # 将消息转换为向量
        message_vectors = self.vectorizer.transform(messages)
        
        # 训练K-means模型
        n_clusters = min(self.config.cluster_max_clusters, max(2, len(messages) // 100))
        self.cluster_model = KMeans(
            n_clusters=n_clusters,
            random_state=42,
            n_init=10
        )
        self.cluster_model.fit(message_vectors)
        
        logger.info(f"聚类模型训练完成，聚类数量: {n_clusters}")
    
    def _save_model_state(self, version: str = None):
        """保存模型状态"""
        try:
            import joblib
            # 使用指定版本或当前版本
            model_version = version if version else self.config.model_version
            
            # 确保模型目录存在
            model_dir = os.path.join(os.path.dirname(self.db_path), 'models', model_version)
            os.makedirs(model_dir, exist_ok=True)
            
            # 保存TF-IDF向量器
            if self.vectorizer:
                vectorizer_path = os.path.join(model_dir, 'tfidf_vectorizer.pkl')
                with open(vectorizer_path, 'wb') as f:
                    joblib.dump(self.vectorizer, f)
                logger.info(f"TF-IDF向量器已保存到版本 {model_version}: {vectorizer_path}")
            
            # 保存聚类模型
            if self.cluster_model:
                cluster_path = os.path.join(model_dir, 'cluster_model.pkl')
                with open(cluster_path, 'wb') as f:
                    joblib.dump(self.cluster_model, f)
                logger.info(f"聚类模型已保存到版本 {model_version}: {cluster_path}")
            
            # 保存训练元数据
            metadata = {
                'last_training_time': self.last_training_time,
                'message_count_since_last_training': self.message_count_since_last_training,
                'vocabulary_size': len(self.vectorizer.vocabulary_) if self.vectorizer else 0,
                'model_version': model_version,
                'saved_time': datetime.now().isoformat()
            }
            metadata_path = os.path.join(model_dir, 'model_metadata.json')
            with open(metadata_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, ensure_ascii=False, indent=2)
            
            # 同时保存到默认目录以保持向后兼容性
            default_model_dir = os.path.join(os.path.dirname(self.db_path), 'models')
            if model_version == self.config.model_version:
                if self.vectorizer:
                    vectorizer_path = os.path.join(default_model_dir, 'tfidf_vectorizer.pkl')
                    with open(vectorizer_path, 'wb') as f:
                        joblib.dump(self.vectorizer, f)
                if self.cluster_model:
                    cluster_path = os.path.join(default_model_dir, 'cluster_model.pkl')
                    with open(cluster_path, 'wb') as f:
                        joblib.dump(self.cluster_model, f)
                metadata_path = os.path.join(default_model_dir, 'model_metadata.json')
                with open(metadata_path, 'w', encoding='utf-8') as f:
                    json.dump(metadata, f, ensure_ascii=False, indent=2)
            
            logger.info(f"模型状态已完整保存到版本 {model_version}")
        except Exception as e:
            logger.error(f"保存模型状态失败: {e}")
    
    def _load_model_state(self, version: str = None):
        """加载模型状态"""
        try:
            import joblib
            
            # 使用指定版本或当前版本
            if version:
                model_dir = os.path.join(os.path.dirname(self.db_path), 'models', version)
            else:
                # 尝试加载当前版本
                model_dir = os.path.join(os.path.dirname(self.db_path), 'models', self.config.model_version)
                # 如果当前版本目录不存在，使用默认目录
                if not os.path.exists(model_dir):
                    model_dir = os.path.join(os.path.dirname(self.db_path), 'models')
            
            if not os.path.exists(model_dir):
                logger.warning(f"模型目录 {model_dir} 不存在，将从头开始训练")
                return False
            
            # 加载TF-IDF向量器
            vectorizer_path = os.path.join(model_dir, 'tfidf_vectorizer.pkl')
            if os.path.exists(vectorizer_path):
                with open(vectorizer_path, 'rb') as f:
                    self.vectorizer = joblib.load(f)
                logger.info(f"已加载TF-IDF向量器，词汇表大小: {len(self.vectorizer.vocabulary_)}")
            else:
                logger.warning("未找到TF-IDF向量器文件")
            
            # 加载聚类模型
            cluster_path = os.path.join(model_dir, 'cluster_model.pkl')
            if os.path.exists(cluster_path) and self.vectorizer:
                with open(cluster_path, 'rb') as f:
                    self.cluster_model = joblib.load(f)
                logger.info(f"已加载聚类模型")
            else:
                logger.warning("未找到聚类模型文件或向量器未加载")
            
            # 加载训练元数据
            metadata_path = os.path.join(model_dir, 'model_metadata.json')
            if os.path.exists(metadata_path):
                with open(metadata_path, 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
                self.last_training_time = metadata.get('last_training_time', 0)
                self.message_count_since_last_training = metadata.get('message_count_since_last_training', 0)
                logger.info(f"已加载模型元数据，上次训练时间: {datetime.fromtimestamp(self.last_training_time).strftime('%Y-%m-%d %H:%M:%S') if self.last_training_time else '从未训练'}")
            
            logger.info(f"已成功加载模型版本 {version if version else self.config.model_version}")
            return self.vectorizer is not None
        except Exception as e:
            logger.error(f"加载模型状态失败: {e}")
            return False
    
    def _simple_keyword_match(self, message: str, candidates: List[str]) -> Optional[str]:
        """当向量匹配失败时，使用简单的关键词匹配作为后备方案"""
        try:
            # 提取消息关键词
            message_keywords = set(jieba.cut_for_search(message))
            
            if not message_keywords:
                return None
            
            best_match = None
            best_score = 0
            
            # 对每个候选回复计算关键词匹配度
            for candidate in candidates:
                candidate_keywords = set(jieba.cut_for_search(candidate))
                intersection = message_keywords.intersection(candidate_keywords)
                
                # 计算匹配得分
                if len(candidate_keywords) > 0:
                    match_score = len(intersection) / len(candidate_keywords)
                else:
                    match_score = 0
                
                # 长度匹配奖励
                message_len = len(message)
                candidate_len = len(candidate)
                length_ratio = candidate_len / max(message_len, 1)
                
                # 如果长度差异太大，降低分数
                if length_ratio < 0.3 or length_ratio > 3.0:
                    match_score *= 0.5
                
                # 更新最佳匹配
                if match_score > best_score:
                    best_score = match_score
                    best_match = candidate
            
            # 如果匹配度足够高，返回最佳匹配
            if best_match and best_score > 0.2:  # 0.2是一个较低的阈值，确保至少有一定匹配度
                return best_match
            
            return None
        except Exception as e:
            logger.error(f"简单关键词匹配失败: {e}")
            return None
    
    def _save_training_history(self, message_count: int, duration: float, metrics: Dict, status: str = "success", error: str = ""):
        """保存训练历史记录"""
        import sqlite3
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    """INSERT INTO training_history 
                    (timestamp, message_count, duration, model_version, status, metrics) 
                    VALUES (?, ?, ?, ?, ?, ?)""",
                    (
                        int(time.time()),
                        message_count,
                        duration,
                        self.config.model_version,
                        status,
                        json.dumps({**metrics, "error": error})
                    )
                )
                conn.commit()
        except Exception as e:
            logger.error(f"保存训练历史失败: {e}")
    
    def record_metric(self, metric_type: str, value: float, details: Dict = None):
        """记录性能指标"""
        import sqlite3
        
        # 更新内存中的指标
        if metric_type in self.performance_metrics:
            self.performance_metrics[metric_type].append(value)
            # 保持指标列表不要太长
            if len(self.performance_metrics[metric_type]) > self.config.metric_history_size:
                self.performance_metrics[metric_type] = self.performance_metrics[metric_type][-self.config.metric_history_size:]
        
        # 保存到数据库
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    """INSERT INTO performance_metrics 
                    (timestamp, metric_type, value, details) 
                    VALUES (?, ?, ?, ?)""",
                    (
                        int(time.time()),
                        metric_type,
                        value,
                        json.dumps(details) if details else ""
                    )
                )
                conn.commit()
        except Exception as e:
            logger.error(f"保存指标失败: {e}")
    
    def record_user_feedback(self, user_id: str, message: str, reply: str, feedback_type: str, feedback_score: float, feedback_content: str = ""):
        """记录用户反馈"""
        import sqlite3
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    '''INSERT INTO user_feedback 
                    (timestamp, user_id, message, reply, feedback_type, feedback_score, feedback_content) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)''',
                    (
                        int(time.time()),
                        user_id,
                        message,
                        reply,
                        feedback_type,
                        feedback_score,
                        feedback_content
                    )
                )
                conn.commit()
            
            # 更新用户满意度指标
            if 'user_satisfaction' in self.performance_metrics:
                self.performance_metrics['user_satisfaction'].append(feedback_score)
                if len(self.performance_metrics['user_satisfaction']) > self.config.metric_history_size:
                    self.performance_metrics['user_satisfaction'] = self.performance_metrics['user_satisfaction'][-self.config.metric_history_size:]
            
            logger.info(f"记录用户反馈成功: 用户{user_id}, 评分{feedback_score}")
            
            # 检查是否需要立即调整模型
            asyncio.create_task(self._adjust_model_based_on_feedback(message, reply, feedback_score))
            
        except Exception as e:
            logger.error(f"记录用户反馈失败: {e}")
    
    async def _adjust_model_based_on_feedback(self, message: str, reply: str, feedback_score: float):
        """基于用户反馈调整模型"""
        # 如果反馈很差，降低该回复的权重
        if feedback_score <= 2.0:
            await self._update_reply_weight(message, reply, 0.5)  # 降低权重
        # 如果反馈很好，增加该回复的权重
        elif feedback_score >= 4.0:
            await self._update_reply_weight(message, reply, 1.5)  # 增加权重
    
    async def _update_reply_weight(self, message: str, reply: str, weight_multiplier: float):
        """更新回复的权重"""
        import sqlite3
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 查找现有权重
                cursor.execute(
                    '''SELECT weight FROM reply_weights WHERE message = ? AND reply = ?''',
                    (message, reply)
                )
                result = cursor.fetchone()
                
                if result:
                    # 更新现有权重
                    new_weight = result[0] * weight_multiplier
                    cursor.execute(
                        '''UPDATE reply_weights SET weight = ?, last_used = ? WHERE message = ? AND reply = ?''',
                        (new_weight, int(time.time()), message, reply)
                    )
                else:
                    # 创建新的权重记录
                    cursor.execute(
                        '''INSERT INTO reply_weights (message, reply, weight, usage_count, last_used) 
                        VALUES (?, ?, ?, ?, ?)''',
                        (message, reply, weight_multiplier, 1, int(time.time()))
                    )
                
                conn.commit()
                logger.debug(f"更新回复权重成功: {message} -> {reply}, 权重因子: {weight_multiplier}")
                
        except Exception as e:
            logger.error(f"更新回复权重失败: {e}")
    
    def _get_current_metrics_summary(self) -> Dict:
        """获取当前指标摘要 - 增强版，包含趋势分析和综合评分"""
        summary = {}
        
        # 计算每个指标的详细统计信息
        for metric_type, values in self.performance_metrics.items():
            if values:
                # 基本统计信息
                summary[f"{metric_type}_avg"] = np.mean(values)
                summary[f"{metric_type}_max"] = np.max(values)
                summary[f"{metric_type}_min"] = np.min(values)
                summary[f"{metric_type}_count"] = len(values)
                summary[f"{metric_type}_median"] = np.median(values)
                summary[f"{metric_type}_std"] = np.std(values)
                
                # 趋势分析 - 比较最近10个值与之前的值
                if len(values) >= 20:
                    recent_values = values[-10:]
                    previous_values = values[-20:-10]
                    recent_avg = np.mean(recent_values)
                    previous_avg = np.mean(previous_values)
                    
                    # 计算趋势（上升/下降/稳定）
                    trend = 0.0
                    if previous_avg > 0:
                        trend = (recent_avg - previous_avg) / previous_avg
                    
                    summary[f"{metric_type}_trend"] = trend
                    summary[f"{metric_type}_trend_direction"] = "improving" if trend > 0.05 else "declining" if trend < -0.05 else "stable"
        
        # 计算综合性能评分
        if summary:
            # 选择关键指标进行综合评分
            key_metrics = [
                "reply_relevance_avg",
                "conversation_coherence_avg",
                "user_satisfaction_avg",
                "context_awareness_avg",
                "logical_consistency_avg"
            ]
            
            # 计算关键指标的平均值作为综合评分
            key_metric_values = [summary[metric] for metric in key_metrics if metric in summary]
            if key_metric_values:
                summary["overall_performance"] = np.mean(key_metric_values)
                
                # 基于综合评分判断模型状态
                if summary["overall_performance"] >= 0.85:
                    summary["model_status"] = "excellent"
                elif summary["overall_performance"] >= 0.7:
                    summary["model_status"] = "good"
                elif summary["overall_performance"] >= 0.5:
                    summary["model_status"] = "average"
                else:
                    summary["model_status"] = "poor"
        
        # 添加模型基本信息
        summary["model_version"] = self.config.model_version
        summary["time_since_last_training"] = time.time() - self.last_training_time if self.last_training_time > 0 else float('inf')
        summary["message_count_since_training"] = self.message_count_since_last_training
        
        return summary
    
    async def evaluate_reply_quality(self, query: str, reply: str) -> float:
        """评估回复质量"""
        if not query or not reply:
            return 0.0
        
        try:
            # 基础相关性评分
            relevance_score = self._calculate_relevance_score(query, reply)
            
            # 长度适宜性评分
            length_score = self._calculate_length_score(query, reply)
            
            # 内容质量评分
            content_score = self._calculate_content_quality_score(reply)
            
            # 上下文连贯性评分 (如果有上下文)
            context_coherence = 0.5  # 默认值
            if hasattr(self, 'context_memory') and len(self.context_memory) > 0:
                context_coherence = self._calculate_context_coherence_score(query, reply)
            
            # 综合评分
            final_score = (relevance_score * 0.4 + length_score * 0.1 + content_score * 0.2 + context_coherence * 0.3)
            
            # 记录指标
            self.record_metric('reply_relevance', final_score, {
                'query': query[:50],
                'reply': reply[:50]
            })
            self.record_metric('context_awareness', context_coherence, {
                'query': query[:50],
                'reply': reply[:50]
            })
            
            return final_score
        except Exception as e:
            logger.error(f"评估回复质量失败: {e}")
            return 0.0
    
    def _calculate_relevance_score(self, query: str, reply: str) -> float:
        """计算查询与回复的相关性评分"""
        if not self.vectorizer:
            # 简化的相关性计算
            query_words = set(jieba.cut_for_search(query))
            reply_words = set(jieba.cut_for_search(reply))
            intersection = query_words.intersection(reply_words)
            
            if not query_words:
                return 0.5  # 默认值
            
            return len(intersection) / len(query_words)
        
        try:
            # 使用TF-IDF和余弦相似度计算相关性
            vectors = self.vectorizer.transform([query, reply])
            similarity = cosine_similarity(vectors[0:1], vectors[1:2])[0][0]
            return similarity
        except Exception as e:
            logger.error(f"计算相关性失败: {e}")
            # 回退到简单方法
            query_words = set(jieba.cut_for_search(query))
            reply_words = set(jieba.cut_for_search(reply))
            intersection = query_words.intersection(reply_words)
            
            if not query_words:
                return 0.5  # 默认值
            
            return len(intersection) / len(query_words)
    
    def _calculate_length_score(self, query: str, reply: str) -> float:
        """计算回复长度适宜性评分"""
        query_length = len(query)
        reply_length = len(reply)
        
        if query_length == 0:
            return 0.5  # 默认值
        
        # 理想的回复长度应该在查询长度的0.5到2倍之间
        if 0.5 * query_length <= reply_length <= 2.0 * query_length:
            return 1.0
        elif reply_length < 0.5 * query_length:
            return reply_length / (0.5 * query_length) * 0.5 + 0.5
        else:
            # 过长的回复，评分递减
            ratio = 2.0 * query_length / reply_length
            return max(0.3, ratio)
    
    def _evaluate_content_quality(self, content: str) -> float:
        """评估内容质量分数（0-1）"""
        # 复用现有的内容质量计算逻辑
        return self._calculate_content_quality_score(content)
    
    def _calculate_content_quality_score(self, reply: str) -> float:
        """计算回复内容质量评分 - 增强版"""
        # 检查是否为空
        if not reply.strip():
            return 0.0
        
        # 检查是否包含禁用词
        try:
            prohibited_words = getattr(self.config, 'prohibited_words', [])
            if any(word in reply for word in prohibited_words):
                return 0.0
        except (TypeError, AttributeError):
            # 如果禁用词配置不存在或格式错误，跳过检查
            pass
        
        # 检查句子完整性（简单检查是否包含句号、问号、感叹号等）
        has_ending_punctuation = any(p in reply for p in ["。", "!", "！", "?", "？", "."])
        
        # 计算词汇多样性 - 只分词一次以提高性能
        words = list(jieba.cut_for_search(reply))
        word_count = len(words)
        unique_words = set(words)
        
        if word_count == 0:
            diversity_score = 0.0
        else:
            diversity_score = min(1.0, len(unique_words) / word_count)
        
        # 增加逻辑一致性评分
        logic_consistency_score = self._evaluate_logic_consistency_score(reply)
        
        # 增加情感表达能力评分
        emotional_expression_score = self._evaluate_emotional_expression_score(reply)
        
        # 增加内容丰富度评分
        content_richness_score = self._evaluate_content_richness_score(reply)
        
        # 综合评分
        punctuation_score = 0.8 if has_ending_punctuation else 0.5
        
        # 权重分配
        total_score = (
            diversity_score * 0.25 +
            punctuation_score * 0.15 +
            logic_consistency_score * 0.25 +
            emotional_expression_score * 0.15 +
            content_richness_score * 0.2
        )
        
        return min(1.0, total_score)
    
    def _evaluate_logic_consistency_score(self, text: str) -> float:
        """评估逻辑一致性评分"""
        # 检查逻辑关系词的使用
        logic_score = 0.0
        logic_count = 0
        
        # 检查各种逻辑关系词
        for relation_type, words in self.logic_relations.items():
            for word in words:
                if word in text:
                    logic_count += 1
        
        # 根据逻辑关系词的数量计算评分
        if logic_count > 0:
            logic_score = min(1.0, logic_count / 3)  # 最多3个逻辑关系词
        
        # 检查句子之间的连贯性（简单检查是否包含连接词）
        connective_words = ["所以", "因此", "但是", "而且", "此外", "同时", "另外"]
        for word in connective_words:
            if word in text:
                logic_score = min(1.0, logic_score + 0.2)
                break
        
        return logic_score
    
    def _evaluate_emotional_expression_score(self, text: str) -> float:
        """评估情感表达能力评分"""
        # 检查情感词的使用
        emotional_score = 0.0
        emotional_count = 0
        
        # 检查情感词
        for emotion, words in self.logic_relations.items():
            for word in words:
                if word in text:
                    emotional_count += 1
        
        # 根据情感词的数量计算评分
        if emotional_count > 0:
            emotional_score = min(1.0, emotional_count / 2)  # 最多2个情感表达
        
        # 检查表情符号
        emoji_patterns = [":", "^_", "≧▽≦", "╹▽╹", "๑•̀ㅂ•́)و✧"]
        for pattern in emoji_patterns:
            if pattern in text:
                emotional_score = min(1.0, emotional_score + 0.3)
                break
        
        return emotional_score
    
    def _evaluate_content_richness_score(self, text: str) -> float:
        """评估内容丰富度评分"""
        # 检查文本长度
        length = len(text)
        
        # 根据长度计算基础评分
        if length < 5:
            richness_score = 0.3
        elif length < 10:
            richness_score = 0.5
        elif length < 20:
            richness_score = 0.7
        elif length < 50:
            richness_score = 0.9
        else:
            richness_score = 1.0
        
        # 检查是否包含具体信息（数字、时间、地点等）
        has_specific_info = any(pattern in text for pattern in ["今天", "明天", "昨天", "现在", "以后", "之前", "这里", "那里", "地方"])
        if has_specific_info:
            richness_score = min(1.0, richness_score + 0.2)
        
        return richness_score
    
    async def get_performance_report(self, days: int = 7) -> Dict:
        """获取性能报告"""
        import sqlite3
        
        report = {
            'time_range': f"最近{days}天",
            'training_sessions': [],
            'metrics_summary': {},
            'improvement_trends': {}
        }
        
        try:
            cutoff_time = int((datetime.now() - timedelta(days=days)).timestamp())
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 获取训练会话
                cursor.execute(
                    "SELECT timestamp, message_count, duration, status, metrics FROM training_history WHERE timestamp > ? ORDER BY timestamp DESC",
                    (cutoff_time,)
                )
                training_sessions = cursor.fetchall()
                
                for ts, msg_count, duration, status, metrics_json in training_sessions:
                    try:
                        metrics = json.loads(metrics_json) if metrics_json else {}
                    except json.JSONDecodeError:
                        metrics = {}
                    
                    report['training_sessions'].append({
                        'time': datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S'),
                        'message_count': msg_count,
                        'duration': duration,
                        'status': status,
                        'metrics': metrics
                    })
                
                # 获取性能指标
                for metric_type in self.performance_metrics.keys():
                    cursor.execute(
                        "SELECT AVG(value), MAX(value), MIN(value), COUNT(*) FROM performance_metrics WHERE metric_type = ? AND timestamp > ?",
                        (metric_type, cutoff_time)
                    )
                    result = cursor.fetchone()
                    if result and result[0] is not None:
                        report['metrics_summary'][metric_type] = {
                            'average': float(result[0]),
                            'max': float(result[1]),
                            'min': float(result[2]),
                            'count': int(result[3])
                        }
        except Exception as e:
            logger.error(f"生成性能报告失败: {e}")
        
        return report
    
    def increment_message_count(self):
        """增加消息计数"""
        self.message_count_since_last_training += 1
        
        # 如果消息计数达到阈值，触发即时训练检查
        if self.message_count_since_last_training % self.config.message_count_check_interval == 0:
            asyncio.create_task(self._check_and_train_if_needed())
    
    async def _check_and_train_if_needed(self):
        """检查并在需要时触发训练"""
        if await self._should_train():
            await self.perform_training()
    
    def get_model_info(self, version: str = None) -> Dict:
        """获取模型信息"""
        if version and version != self.config.model_version:
            # 获取特定版本的信息
            for v in self.model_versions:
                if v["version"] == version:
                    return {
                        "model_version": v["version"],
                        "created_at": v["created_at"],
                        "message_count": v["message_count"],
                        "status": v["status"]
                    }
            return {"error": "Version not found"}
        
        info = {
            'model_version': self.config.model_version,
            'last_training_time': datetime.fromtimestamp(self.last_training_time).strftime('%Y-%m-%d %H:%M:%S') if self.last_training_time else '从未训练',
            'message_count_since_last_training': self.message_count_since_last_training,
            'is_trained': self.vectorizer is not None,
            'vocabulary_size': len(self.vectorizer.vocabulary_) if self.vectorizer else 0,
        }
        
        return info
    
    def get_all_versions(self) -> List[Dict]:
        """获取所有模型版本"""
        return self.model_versions
    
    async def switch_model_version(self, version: str) -> bool:
        """切换到指定版本"""
        # 检查版本是否存在
        version_exists = any(v["version"] == version for v in self.model_versions)
        if not version_exists:
            logger.error(f"版本 {version} 不存在")
            return False
        
        try:
            # 保存当前状态
            await asyncio.to_thread(self._save_model_state)
            
            # 加载目标版本
            if not self._load_model_state(version):
                logger.error(f"加载版本 {version} 失败")
                return False
            
            # 更新当前版本
            old_version = self.config.model_version
            self.config.model_version = version
            
            # 更新版本状态
            for v in self.model_versions:
                if v["version"] == version:
                    v["status"] = "active"
                    v["last_used"] = datetime.now().isoformat()
                elif v["version"] == old_version:
                    v["status"] = "inactive"
            
            logger.info(f"成功切换模型版本从 {old_version} 到 {version}")
            return True
        except Exception as e:
            logger.error(f"切换模型版本失败: {e}")
            return False
    
    def compare_versions(self, version1: str, version2: str) -> Dict:
        """比较两个版本"""
        v1_info = self.get_model_info(version1)
        v2_info = self.get_model_info(version2)
        
        if "error" in v1_info or "error" in v2_info:
            return {"error": "One or both versions not found"}
        
        # 获取性能指标比较
        # 这里可以扩展为更详细的比较
        return {
            "version1": v1_info,
            "version2": v2_info,
            "comparison": {
                "vocabulary_diff": v1_info.get("vocabulary_size", 0) - v2_info.get("vocabulary_size", 0),
                "message_count_diff": v1_info.get("message_count", 0) - v2_info.get("message_count", 0)
            }
        }
    
    async def cleanup_old_versions(self, keep_latest: int = 5) -> bool:
        """清理旧版本，只保留最新的N个版本"""
        if len(self.model_versions) <= keep_latest:
            return True
        
        try:
            # 按创建时间排序版本
            sorted_versions = sorted(self.model_versions, key=lambda x: x["created_at"], reverse=True)
            versions_to_remove = sorted_versions[keep_latest:]
            
            for v in versions_to_remove:
                if v["status"] == "active":
                    continue  # 不删除当前活跃版本
                
                # 删除版本文件
                version_dir = os.path.join(os.path.dirname(self.db_path), 'models', v["version"])
                if os.path.exists(version_dir):
                    import shutil
                    shutil.rmtree(version_dir)
                
                # 从版本列表中移除
                self.model_versions.remove(v)
                logger.info(f"已清理旧版本 {v['version']}")
            
            return True
        except Exception as e:
            logger.error(f"清理旧版本失败: {e}")
            return False
    
    def find_relevant_reply(self, message: str, user_id: str = None, chat_history: List[str] = None) -> Optional[str]:
        """增强版回复查找方法，包含逻辑一致性检查、情感分析和语境理解能力"""
        if not message or not self.vectorizer:
            return None
        
        try:
            # 记录查找开始时间
            start_time = time.time()
            
            # 检查vectorizer是否已经训练过
            if not hasattr(self.vectorizer, 'vocabulary_') or len(self.vectorizer.vocabulary_) == 0:
                logger.warning("向量器尚未训练，无法进行相似度匹配")
                # 即使没有训练好的向量器，也尝试提供一个合理的默认回复
                return self._generate_fallback_reply(message)
            
            # 情感分析 - 分析用户消息的情感
            sentiment_analysis = self.semantic_analyzer.analyze_sentiment(message)
            sentiment_score = sentiment_analysis['score']
            is_positive = sentiment_score > 0.5
            is_negative = sentiment_score < -0.5
            
            # 语境分析 - 分析当前对话的语境
            context_analysis = self._analyze_context(message, user_id, chat_history)
            context_type = context_analysis.get('type', 'general')
            key_topics = context_analysis.get('topics', [])
            
            # 生成查询缓存键
            cache_key = f"{user_id}:{message[:50]}:{context_type}:{','.join(key_topics[:3])}"
            
            # 检查查询缓存
            if cache_key in self.query_cache:
                cached_result = self.query_cache[cache_key]
                if time.time() - cached_result['timestamp'] < 3600:  # 缓存1小时
                    logger.debug(f"使用查询缓存: {cache_key}")
                    candidates = cached_result['candidates']
                    candidate_scores = cached_result['candidate_scores']
                else:
                    # 缓存过期，删除
                    del self.query_cache[cache_key]
                    return self.find_relevant_reply(message, user_id, chat_history)
            else:
                # 从数据库获取高质量消息用于匹配，优化查询性能
                import sqlite3
                
                with sqlite3.connect(self.db_path) as conn:
                    cursor = conn.cursor()
                    
                    # 构建查询条件，基础条件
                    query = "SELECT message, quality_score, timestamp FROM chat_logs WHERE quality_score >= ?"
                    params = [self.config.message_quality_threshold]
                    
                    # 如果有用户ID，优先使用该用户的历史高质量回复
                    if user_id:
                        query += " AND user_id = ?"
                        params.append(user_id)
                    
                    # 仅使用最重要的逻辑关系词进行筛选（减少LIKE操作符使用）
                    logic_words = self._get_representative_logic_words(2)  # 进一步减少到2个
                    if logic_words:
                        query += " AND (" + " OR ".join([f"message LIKE ?" for _ in logic_words]) + ")"
                        params.extend([f"%{word}%" for word in logic_words])
                    
                    # 根据情感添加筛选条件 - 使用更简单的条件
                    if is_positive:
                        # 积极情感，使用少量核心积极词
                        try:
                            # positive_words是字典，需要获取键列表后再切片
                            positive_words = list(self.semantic_analyzer.positive_words.keys())[:3]  # 进一步限制为3个
                            if positive_words:
                                query += " AND (" + " OR ".join([f"message LIKE ?" for _ in positive_words]) + ")"
                                params.extend([f"%{word}%" for word in positive_words])
                        except (AttributeError, TypeError):
                            # 如果positive_words不存在或不是字典，跳过此条件
                            pass
                    elif is_negative:
                        # 消极情感，使用少量核心安慰词
                        query += " AND (message LIKE ? OR message LIKE ?)"
                        params.extend(["%别担心%", "%没关系%"])
                    
                    # 根据语境类型调整查询 - 简化条件
                    if context_type == 'question':
                        query += " AND (message LIKE ?)"
                        params.append("%因为%")
                    elif context_type == 'greeting':
                        query += " AND (message LIKE ?)"
                        params.append("%你好%")
                    
                    # 添加主题关键词筛选 - 限制数量
                    if key_topics:
                        limited_topics = key_topics[:1]  # 进一步限制为1个主题词
                        if limited_topics:
                            query += " AND (" + " OR ".join([f"message LIKE ?" for _ in limited_topics]) + ")"
                            params.extend([f"%{topic}%" for topic in limited_topics])
                    
                    # 优化排序：先按质量分数排序，再按时间排序，避免RANDOM()
                    query += " ORDER BY quality_score DESC, timestamp DESC LIMIT ?"
                    params.append(min(self.config.reply_candidate_limit, 100))  # 限制候选数量，提高性能
                    
                    cursor.execute(query, params)
                    results = cursor.fetchall()
                    
                    # 提取候选消息和它们的质量分数
                    candidates = [row[0] for row in results]
                    candidate_scores = [row[1] for row in results] if results else []
                    
                    # 更新查询缓存
                    if candidates:
                        self.query_cache[cache_key] = {
                            'timestamp': time.time(),
                            'candidates': candidates,
                            'candidate_scores': candidate_scores
                        }
                        # 限制缓存大小
                        if len(self.query_cache) > self.cache_size_limit:
                            # 移除最旧的缓存项
                            oldest_key = next(iter(self.query_cache.keys()))
                            del self.query_cache[oldest_key]
            
            if not candidates:
                # 如果没有找到候选消息，尝试使用更宽松的条件
                logger.warning("未找到高质量候选消息，尝试使用更宽松的条件")
                candidates = self._get_fallback_candidates()
                if not candidates:
                    return self._generate_fallback_reply(message)
            
            # 使用增强的TF-IDF向量器进行相似度计算
            all_texts = [message] + candidates
            
            # 尝试转换文本为向量，捕获可能的错误
            try:
                vectors = self.vectorizer.transform(all_texts)
            except ValueError as e:
                logger.error(f"向量转换失败: {e}")
                # 如果转换失败，尝试使用增强的关键词匹配
                return self._enhanced_keyword_match(message, candidates, chat_history)
            
            # 计算查询与所有候选消息的相似度
            similarities = cosine_similarity(vectors[0:1], vectors[1:])[0]
            
            # 计算增强的语义相似度（使用改进的语义分析器）
            enhanced_similarities = []
            # 限制需要计算语义相似度的候选数量
            limited_candidates = candidates[:50]  # 只计算前50个候选的语义相似度
            for i, candidate in enumerate(limited_candidates):
                # 使用改进的语义分析器计算更高级的语义相似度
                semantic_sim = self.semantic_analyzer.calculate_semantic_similarity(message, candidate)
                # 结合传统相似度和增强语义相似度
                if i < len(similarities):
                    combined_sim = similarities[i] * 0.7 + semantic_sim * 0.3
                else:
                    combined_sim = semantic_sim
                enhanced_similarities.append(combined_sim)
            # 对于剩余的候选，直接使用传统相似度
            for i in range(len(limited_candidates), len(candidates)):
                if i < len(similarities):
                    enhanced_similarities.append(similarities[i])
                else:
                    enhanced_similarities.append(0.0)
            
            # 主题分类 - 分析用户消息和候选回复的主题
            user_topic = self.semantic_analyzer.classify_topic(message)
            
            # 查询常识知识库
            knowledge_answer = self.semantic_analyzer.query_knowledge_base(message)
            
            # 增强的多因素评分系统，包含情感匹配、语境适配、主题匹配和常识知识整合
            enhanced_scores = []
            # 限制需要计算完整评分的候选数量
            top_candidates = sorted(enumerate(enhanced_similarities), key=lambda x: x[1], reverse=True)[:30]  # 只对前30个候选进行完整评分
            top_indices = {i for i, _ in top_candidates}  # 使用集合提高查找效率
            
            for i, (similarity, enhanced_similarity, candidate) in enumerate(zip(similarities, enhanced_similarities, candidates)):
                # 对于非前30的候选，直接使用增强语义相似度作为评分
                if i not in top_indices:
                    enhanced_scores.append(enhanced_similarity)
                    continue
                
                # 基础相似度评分 - 使用增强的语义相似度
                score = enhanced_similarity
                
                # 质量分数加权
                if candidate_scores and i < len(candidate_scores):
                    score = score * 0.7 + candidate_scores[i] * 0.3
                
                # 逻辑一致性评分
                logic_score = self._evaluate_logic_consistency_for_reply(message, candidate)
                score = score * 0.8 + logic_score * 0.2
                
                # 语义丰富度评分
                semantic_score = self._evaluate_semantic_richness(candidate)
                score = score * 0.9 + semantic_score * 0.1
                
                # 上下文连贯性评分
                context_score = self._evaluate_context_coherence(candidate, chat_history)
                score = score * 0.8 + context_score * 0.2
                
                # 情感匹配评分
                candidate_sentiment = self.semantic_analyzer.analyze_sentiment(candidate)
                candidate_score = candidate_sentiment['score']
                
                # 根据用户情感调整候选回复的评分
                if is_positive:
                    # 积极情感的用户，优先选择积极的回复
                    if candidate_score > 0.3:
                        score *= 1.2
                    elif candidate_score < -0.3:
                        score *= 0.8
                elif is_negative:
                    # 消极情感的用户，优先选择安慰性或中性的回复
                    if -0.1 <= candidate_score <= 0.7:
                        score *= 1.2
                    elif candidate_score < -0.5:
                        score *= 0.8
                
                # 语境适配评分
                context_fit_score = self._evaluate_context_fit(candidate, context_type, key_topics)
                score = score * 0.9 + context_fit_score * 0.1
                
                # 主题匹配评分
                candidate_topic = self.semantic_analyzer.classify_topic(candidate)
                if user_topic == candidate_topic and user_topic != 'unknown':
                    # 如果主题匹配且不是未知主题，增加评分
                    score *= 1.1
                
                # 常识知识匹配评分
                if knowledge_answer:
                    # 如果存在常识知识答案，增加相关回复的评分
                    knowledge_sim = self.semantic_analyzer.calculate_semantic_similarity(candidate, knowledge_answer)
                    if knowledge_sim > 0.5:
                        score *= 1.15
                
                # 避免近期重复回复的惩罚
                if hasattr(self, 'recent_replies') and candidate in self.recent_replies:
                    recency_penalty = 1.0 - (self.recent_replies.index(candidate) / len(self.recent_replies)) * 0.5
                    score *= recency_penalty
                
                # 回复权重因子
                reply_weight = self._get_reply_weight(message, candidate)
                score *= reply_weight
                
                enhanced_scores.append(score)
            
            # 归一化分数
            max_score = max(enhanced_scores) if enhanced_scores else 0
            if max_score > 0:
                normalized_scores = [s / max_score for s in enhanced_scores]
            else:
                normalized_scores = enhanced_scores
            
            # 找到综合评分最高的消息
            best_index = np.argmax(normalized_scores)
            best_score = normalized_scores[best_index]
            best_similarity = similarities[best_index]
            
            # 如果综合评分低于阈值，不返回任何内容
            min_score_threshold = getattr(self.config, 'min_reply_score', 0.35)
            if best_score < min_score_threshold:
                logger.info(f"最佳回复综合评分 {best_score} 低于阈值 {min_score_threshold}")
                # 尝试使用常识知识库生成回复
                if knowledge_answer:
                    return knowledge_answer
                return self._generate_fallback_reply(message)
            
            best_reply = candidates[best_index]
            
            # 在回复中融入常识知识
            if knowledge_answer:
                best_reply = self.semantic_analyzer.enhance_reply_with_knowledge(best_reply, message)
            
            # 更新最近回复缓存，避免重复回复
            self._update_recent_replies(best_reply)
            
            # 记录性能指标，包含情感、语境、语义分析和常识知识整合信息
            self.record_metric('reply_relevance', best_similarity, {
                'query': message[:50],
                'reply': best_reply[:50],
                'similarity': best_similarity,
                'enhanced_similarity': enhanced_similarities[best_index],
                'comprehensive_score': best_score,
                'processing_time': time.time() - start_time,
                'sentiment_score': sentiment_score,
                'user_topic': user_topic,
                'reply_topic': self.semantic_analyzer.classify_topic(best_reply),
                'context_type': context_type,
                'knowledge_integrated': bool(knowledge_answer)
            })
            
            # 自我迭代：根据回复质量动态调整阈值
            self._dynamic_threshold_adjustment(best_score, best_similarity)
            
            logger.debug(f"找到相关回复，相似度: {best_similarity:.4f}, 综合评分: {best_score:.4f}, 常识知识整合: {bool(knowledge_answer)}")
            
            return best_reply
        except Exception as e:
            logger.error(f"查找相关回复失败: {e}")
            # 增强的错误恢复机制
            self._enhanced_error_recovery(e)
            # 尝试使用常识知识库生成回复作为后备
            knowledge_answer = self.semantic_analyzer.query_knowledge_base(message)
            if knowledge_answer:
                return knowledge_answer
            # 返回一个默认回复作为最后的后备
            return self._generate_fallback_reply(message)
            
    def _get_logic_word_count_for_search(self) -> int:
        """获取用于搜索的逻辑关系词数量"""
        # 动态调整搜索中的逻辑词数量，避免WHERE条件过长
        max_logic_words = getattr(self.config, 'max_logic_words_for_search', 10)
        total_logic_words = sum(len(words) for words in self.logic_relations.values())
        return min(max_logic_words, max(3, total_logic_words // 5))
        
    def _get_representative_logic_words(self, count: int) -> List[str]:
        """获取代表性的逻辑关系词"""
        # 从每种逻辑关系中随机选择一些词
        selected_words = []
        for relation_type, words in self.logic_relations.items():
            if isinstance(words, dict):  # 对于嵌套结构
                for sub_words in words.values():
                    if sub_words:
                        # 对于列表，随机选择一个
                        if isinstance(sub_words, list):
                            if sub_words:
                                selected_words.extend(random.sample(sub_words, min(2, len(sub_words))))
                        else:  # 对于单个词
                            selected_words.append(sub_words)
            else:  # 对于直接的词列表
                if words and isinstance(words, list):
                    selected_words.extend(random.sample(words, min(2, len(words))))
        
        # 如果选中的词不足，返回所有选中的词；否则随机选择指定数量
        if len(selected_words) <= count:
            return selected_words
        else:
            return random.sample(selected_words, count)
            
    def _get_fallback_candidates(self) -> List[str]:
        """获取更宽松条件的候选消息"""
        try:
            import sqlite3
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                # 使用更低的质量阈值和更大的限制
                lower_threshold = max(0.3, self.config.message_quality_threshold * 0.7)
                larger_limit = min(1000, self.config.reply_candidate_limit * 3)
                
                cursor.execute(
                    "SELECT message FROM chat_logs WHERE quality_score >= ? ORDER BY RANDOM() LIMIT ?",
                    (lower_threshold, larger_limit)
                )
                return [row[0] for row in cursor.fetchall()]
        except Exception as e:
            logger.error(f"获取后备候选消息失败: {e}")
            # 如果数据库查询失败，返回训练缓存中的消息
            return random.sample(self.training_data_cache, min(100, len(self.training_data_cache))) if self.training_data_cache else []
            
    def _enhanced_keyword_match(self, message: str, candidates: List[str], chat_history: List[str] = None) -> Optional[str]:
        """增强版关键词匹配方法"""
        try:
            # 提取消息关键词和逻辑关系词
            message_keywords = set(jieba.cut_for_search(message))
            message_logic_words = set()
            for relation_type, words in self.logic_relations.items():
                if isinstance(words, dict):
                    for sub_words in words.values():
                        if isinstance(sub_words, list):
                            message_logic_words.update(word for word in sub_words if word in message)
                        elif isinstance(sub_words, str) and sub_words in message:
                            message_logic_words.add(sub_words)
                elif isinstance(words, list):
                    message_logic_words.update(word for word in words if word in message)
                elif isinstance(words, str) and words in message:
                    message_logic_words.add(words)
            
            if not message_keywords and not message_logic_words:
                return None
            
            best_match = None
            best_score = 0
            
            # 对每个候选回复计算综合匹配度
            for candidate in candidates:
                candidate_keywords = set(jieba.cut_for_search(candidate))
                
                # 关键词匹配得分
                keyword_intersection = message_keywords.intersection(candidate_keywords)
                if message_keywords:
                    keyword_score = len(keyword_intersection) / len(message_keywords)
                else:
                    keyword_score = 0
                
                # 逻辑关系匹配得分
                candidate_logic_words = set()
                for relation_type, words in self.logic_relations.items():
                    if isinstance(words, dict):
                        for sub_words in words.values():
                            if isinstance(sub_words, list):
                                candidate_logic_words.update(word for word in sub_words if word in candidate)
                            elif isinstance(sub_words, str) and sub_words in candidate:
                                candidate_logic_words.add(sub_words)
                    elif isinstance(words, list):
                        candidate_logic_words.update(word for word in words if word in candidate)
                    elif isinstance(words, str) and words in candidate:
                        candidate_logic_words.add(words)
                
                logic_intersection = message_logic_words.intersection(candidate_logic_words)
                logic_score = len(logic_intersection) / (len(message_logic_words) + 1)  # +1避免除以零
                
                # 长度匹配奖励
                message_len = len(message)
                candidate_len = len(candidate)
                length_ratio = candidate_len / max(message_len, 1)
                length_score = 1.0 if 0.5 <= length_ratio <= 3.0 else max(0.3, min(1.0, 1.0 - abs(1.0 - length_ratio)))
                
                # 上下文连贯性得分（如果有上下文）
                context_score = 0.5  # 默认值
                if chat_history:
                    context_keywords = set()
                    for history_msg in chat_history[-3:]:  # 只考虑最近3条消息
                        context_keywords.update(jieba.cut_for_search(history_msg))
                    context_intersection = context_keywords.intersection(candidate_keywords)
                    context_score = len(context_intersection) / (len(context_keywords) + 1) if context_keywords else 0.5
                
                # 综合得分
                composite_score = keyword_score * 0.5 + logic_score * 0.3 + length_score * 0.1 + context_score * 0.1
                
                # 更新最佳匹配
                if composite_score > best_score:
                    best_score = composite_score
                    best_match = candidate
            
            # 如果匹配度足够高，返回最佳匹配
            if best_match and best_score > 0.25:  # 稍微降低阈值以提高召回率
                return best_match
            
            return None
        except Exception as e:
            logger.error(f"增强版关键词匹配失败: {e}")
            # 回退到原始的简单关键词匹配
            return self._simple_keyword_match(message, candidates)
            
    def _get_reply_weight(self, message: str, reply: str) -> float:
        """获取回复权重"""
        import sqlite3
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT weight FROM reply_weights WHERE message = ? AND reply = ?",
                    (message, reply)
                )
                result = cursor.fetchone()
                if result:
                    return result[0]
        except Exception as e:
            logger.error(f"获取回复权重失败: {e}")
        
        # 默认权重为1.0
        return 1.0
    
    def _update_recent_replies(self, reply: str):
        """更新最近回复缓存，避免重复回复"""
        # 确保recent_replies属性存在
        if not hasattr(self, 'recent_replies'):
            self.recent_replies = []
            
        # 如果回复已经在缓存中，先移除它
        if reply in self.recent_replies:
            self.recent_replies.remove(reply)
        
        # 将回复添加到缓存开头
        self.recent_replies.insert(0, reply)
        
        # 限制缓存大小
        max_recent_replies = getattr(self.config, 'max_recent_replies', 50)
        if len(self.recent_replies) > max_recent_replies:
            self.recent_replies = self.recent_replies[:max_recent_replies]
            
    def _dynamic_threshold_adjustment(self, score: float, similarity: float):
        """根据回复质量动态调整阈值"""
        # 简单的动态调整逻辑：如果连续多次获得高评分回复，可以适当降低阈值以增加多样性
        # 如果连续多次获得低评分回复，可以适当提高阈值以保证质量
        try:
            if not hasattr(self, 'threshold_adjustment_history'):
                self.threshold_adjustment_history = []
                
            # 记录当前评分
            self.threshold_adjustment_history.append({
                'score': score,
                'similarity': similarity,
                'timestamp': time.time()
            })
            
            # 限制历史记录长度
            max_history = getattr(self.config, 'threshold_adjustment_history', 20)
            if len(self.threshold_adjustment_history) > max_history:
                self.threshold_adjustment_history = self.threshold_adjustment_history[-max_history:]
                
            # 只有当有足够的历史记录时才进行调整
            if len(self.threshold_adjustment_history) >= max_history // 2:
                recent_scores = [h['score'] for h in self.threshold_adjustment_history[-5:]]
                avg_recent_score = sum(recent_scores) / len(recent_scores)
                
                # 如果平均评分很高，可以稍微降低相似度阈值以增加多样性
                if avg_recent_score > 0.8:
                    new_threshold = max(0.1, self.config.min_similarity * 0.9)
                    if new_threshold < self.config.min_similarity:
                        self.config.min_similarity = new_threshold
                        logger.info(f"动态降低相似度阈值到: {new_threshold}")
                # 如果平均评分很低，需要提高相似度阈值以保证质量
                elif avg_recent_score < 0.4:
                    new_threshold = min(0.9, self.config.min_similarity * 1.1)
                    if new_threshold > self.config.min_similarity:
                        self.config.min_similarity = new_threshold
                        logger.info(f"动态提高相似度阈值到: {new_threshold}")
        except Exception as e:
            logger.error(f"动态阈值调整失败: {e}")
            
    def _enhanced_error_recovery(self, error: Exception):
        """增强的错误恢复机制"""
        try:
            logger.info("开始增强版错误恢复")
            
            # 记录错误信息
            error_info = {
                'timestamp': time.time(),
                'error_type': type(error).__name__,
                'error_message': str(error),
                'model_version': self.config.model_version
            }
            
            # 分类错误类型并采取相应的恢复策略
            if isinstance(error, MemoryError):
                # 内存错误：清理缓存，降低模型复杂度
                logger.warning("检测到内存错误，执行内存清理")
                # 清理大缓存
                if hasattr(self, 'training_data_cache'):
                    self.training_data_cache = self.training_data_cache[-len(self.training_data_cache)//2:]
                if hasattr(self, 'high_quality_messages'):
                    self.high_quality_messages = self.high_quality_messages[-len(self.high_quality_messages)//2:]
                # 降低模型复杂度
                if hasattr(self.config, 'tfidf_max_features'):
                    self.config.tfidf_max_features = max(5000, int(self.config.tfidf_max_features * 0.7))
            elif isinstance(error, (ValueError, TypeError)) and "vector" in str(error).lower():
                # 向量相关错误：重建向量器
                logger.warning("检测到向量相关错误，重建向量器")
                self.vectorizer = None
            elif isinstance(error, sqlite3.Error):
                # 数据库错误：重新连接数据库
                logger.warning("检测到数据库错误，尝试重新初始化数据库连接")
                # 在下次训练时会自动重新初始化
            else:
                # 其他错误：重置关键组件
                logger.warning(f"检测到未知类型错误: {type(error).__name__}，重置关键组件")
                self.vectorizer = None
                self.cluster_model = None
                
            # 记录恢复尝试
            logger.info("增强版错误恢复尝试完成")
        except Exception as recovery_error:
            logger.error(f"增强版错误恢复也失败: {recovery_error}")
            
    def _analyze_context(self, message: str, user_id: str = None, chat_history: List[str] = None) -> Dict:
        """分析当前对话的语境 - 增强版本，结合对话历史和上下文记忆"""
        context_analysis = {
            'type': 'general',
            'topics': [],
            'sentiment': None,
            'dialogue_theme': 'general',  # 整个对话的主题
            'context_entities': [],       # 上下文中提到的实体
            'dialogue_turns': 0           # 对话轮次数
        }
        
        try:
            # 分析当前消息的情感
            sentiment_result = self.semantic_analyzer.analyze_sentiment(message)
            context_analysis['sentiment'] = sentiment_result['sentiment']
            
            # 分析消息类型 - 扩展类型检测
            # 检查是否是问题
            question_patterns = [
                r"(.+?)[吗嘛呢吧啊]?[？?]$",
                r"为什么(.+)",
                r"怎么(.+)",
                r"如何(.+)",
                r"是不是(.+)",
                r"有没有(.+)",
                r"可否(.+)",
                r"能否(.+)",
                r"要不要(.+)",
                r"该不该(.+)",
                r"会不会(.+)",
                r"什么是(.+)",
                r"什么(.+)",
                r"哪里(.+)",
                r"何时(.+)",
                r"谁(.+)"
            ]
            
            for pattern in question_patterns:
                if re.search(pattern, message):
                    context_analysis['type'] = 'question'
                    break
            
            # 检查是否是问候语
            greetings = ['你好', '嗨', '您好', '早上好', '晚上好', '晚安', '再见', '拜拜', '嗨喽', '你好啊']
            if any(greeting in message for greeting in greetings):
                context_analysis['type'] = 'greeting'
            
            # 检查是否是感谢语
            thanks = ['谢谢', '感谢', '非常感谢', '谢了', '多谢', '感激', '太感谢了']
            if any(thank in message for thank in thanks):
                context_analysis['type'] = 'thanks'
            
            # 检查是否是请求语
            requests = ['请', '麻烦', '能否请', '能不能请', '恳请']
            if any(request in message for request in requests):
                context_analysis['type'] = 'request'
            
            # 检查是否是感叹语
            exclamations = ['！！', '!!!', '啊！', '哇！', '哦！']
            if any(exclamation in message for exclamation in exclamations) or message.strip().endswith('!'):
                context_analysis['type'] = 'exclamation'
            
            # 获取当前消息的关键短语
            current_key_phrases = self.semantic_analyzer.extract_key_phrases(message, top_n=3)
            current_topics = [phrase['phrase'] for phrase in current_key_phrases]
            
            # 分析对话历史，获取整个对话的主题
            all_topics = current_topics.copy()
            dialogue_history = []
            
            # 从chat_history参数获取对话历史
            if chat_history:
                dialogue_history.extend(chat_history)
                dialogue_history.append(message)
            
            # 从上下文记忆中获取更多对话历史
            if user_id and hasattr(self, 'context_memory'):
                if user_id in self.context_memory:
                    memory_context = self.context_memory[user_id]
                    context_analysis['dialogue_turns'] = len(memory_context) * 2  # 每个记忆条目包含用户消息和机器人回复
                    for item in memory_context:
                        if 'user_message' in item and item['user_message']:
                            dialogue_history.append(item['user_message'])
                        if 'bot_reply' in item and item['bot_reply']:
                            dialogue_history.append(item['bot_reply'])
            
            # 如果有对话历史，分析整个对话的主题
            if dialogue_history:
                # 合并所有对话内容
                full_dialogue = " ".join(dialogue_history)
                
                # 提取整个对话的关键短语
                dialogue_key_phrases = self.semantic_analyzer.extract_key_phrases(full_dialogue, top_n=5)
                dialogue_topics = [phrase['phrase'] for phrase in dialogue_key_phrases]
                
                # 合并当前消息和对话的主题，并去重
                all_topics = list(set(all_topics + dialogue_topics))
                
                # 使用语义分析器的主题分类功能识别整个对话的主题
                context_analysis['dialogue_theme'] = self.semantic_analyzer.classify_topic(full_dialogue)
            
            context_analysis['topics'] = all_topics
            
            # 提取上下文中的实体（这里简化处理，使用关键词作为实体）
            # 在实际应用中，可以使用更复杂的实体识别技术
            context_analysis['context_entities'] = [topic for topic in all_topics if len(topic) > 1]
            
            # 结合用户历史分析语境
            if user_id and hasattr(self, 'user_profiles') and user_id in self.user_profiles:
                user_preferences = self.user_profiles[user_id]
                # 将用户偏好的关键词也作为主题
                # 确保添加的元素都是可哈希的
                temp_topics = []
                try:
                    for key in list(user_preferences.keys())[:2]:
                        # 确保key是字符串类型
                        key_str = str(key) if not isinstance(key, (str, int, float, bool)) else key
                        try:
                            # 再次验证是否可哈希
                            set([key_str])
                            temp_topics.append(key_str)
                        except TypeError:
                            # 如果仍然不可哈希，使用安全的字符串表示
                            temp_topics.append(str(key_str))
                    # 合并主题并去重
                    if context_analysis['topics'] and temp_topics:
                        # 使用列表推导式确保所有元素都是可哈希的
                        safe_topics = [str(topic) if not isinstance(topic, (str, int, float, bool)) else topic for topic in context_analysis['topics']]
                        context_analysis['topics'] = list(set(safe_topics + temp_topics))
                except Exception as inner_e:
                    logger.warning(f"处理用户偏好时出错: {inner_e}")
                
        except Exception as e:
            logger.error(f"语境分析失败: {e}")
        
        return context_analysis
    
    def _evaluate_context_fit(self, candidate: str, context_type: str, key_topics: List[str]) -> float:
        """评估候选回复是否适合当前语境"""
        try:
            # 基础分
            fit_score = 0.5
            
            # 根据语境类型调整评分
            if context_type == 'question':
                # 检查是否包含回答相关的关键词
                answer_keywords = ['因为', '所以', '答案是', '解决方案', '建议', '应该', '可以', '需要']
                for keyword in answer_keywords:
                    if keyword in candidate:
                        fit_score += 0.1
                        if fit_score > 1.0:
                            break
            elif context_type == 'greeting':
                # 检查是否是合适的问候语
                greeting_responses = ['你好', '嗨', '您好', '早上好', '晚上好', '很高兴见到你', '有什么可以帮助您的']
                for response in greeting_responses:
                    if response in candidate:
                        fit_score += 0.2
                        break
            elif context_type == 'thanks':
                # 检查是否是合适的感谢回复
                thanks_responses = ['不客气', '这是我应该做的', '很高兴能帮到您', '随时为您服务']
                for response in thanks_responses:
                    if response in candidate:
                        fit_score += 0.2
                        break
            
            # 根据主题词匹配调整评分
            if key_topics:
                matched_topics = 0
                for topic in key_topics:
                    if topic in candidate:
                        matched_topics += 1
                
                topic_match_score = matched_topics / len(key_topics) if key_topics else 0
                fit_score = fit_score * 0.7 + topic_match_score * 0.3
            
            # 归一化到0-1范围
            return min(max(fit_score, 0.0), 1.0)
        except Exception as e:
            logger.error(f"评估语境适配度失败: {e}")
            return 0.5
    
    def _generate_fallback_reply(self, message: str) -> Optional[str]:
        """生成后备回复，考虑情感和语境"""
        # 简单的基于规则的后备回复生成
        fallback_replies = {
            'positive': [
                "很高兴您有这样的感受！",
                "听到这个消息真不错！",
                "我也为您感到开心！",
                "这真是太好了！"
            ],
            'negative': [
                "别担心，一切都会好起来的。",
                "我理解您的感受，这确实不容易。",
                "请相信困难只是暂时的。",
                "需要我为您提供什么帮助吗？"
            ],
            'neutral': [
                "抱歉，我暂时无法理解您的问题，请换个方式提问吧。",
                "这个问题有点难，让我思考一下。",
                "我正在学习中，对于这个问题还不太确定。",
                "您能详细说明一下吗？我想更好地理解您的需求。"
            ],
            'greeting': [
                "您好！有什么可以帮助您的吗？",
                "嗨！很高兴见到您！",
                "早上好！今天有什么计划吗？",
                "晚上好！一天过得怎么样？"
            ],
            'thanks': [
                "不客气，这是我应该做的！",
                "很高兴能帮到您！",
                "随时为您服务！",
                "不用谢！"
            ],
            'question': [
                "关于这个问题，我可以为您提供一些信息。",
                "让我思考一下这个问题...",
                "这个问题很有趣，我来尝试解答。",
                "根据我的理解，这可能是因为..."
            ]
        }
        
        # 分析消息的情感和类型
        sentiment_analysis = self.semantic_analyzer.analyze_sentiment(message)
        sentiment_score = sentiment_analysis['score']
        
        # 确定情感类别
        if sentiment_score > 0.3:
            sentiment_type = 'positive'
        elif sentiment_score < -0.3:
            sentiment_type = 'negative'
        else:
            sentiment_type = 'neutral'
        
        # 确定消息类型
        message_type = 'neutral'
        if any(keyword in message.lower() for keyword in ['你好', '嗨', '您好', '早上好', '晚上好']):
            message_type = 'greeting'
        elif any(keyword in message.lower() for keyword in ['谢谢', '感谢']):
            message_type = 'thanks'
        elif any(keyword in message.lower() for keyword in ['?', '？', '为什么', '怎么', '如何']):
            message_type = 'question'
        
        # 优先根据消息类型选择回复
        if message_type in fallback_replies:
            return random.choice(fallback_replies[message_type])
        
        # 否则根据情感选择回复
        return random.choice(fallback_replies[sentiment_type])
            
    def _evaluate_logic_consistency_for_reply(self, query: str, reply: str) -> float:
        """评估回复与查询之间的逻辑一致性"""
        try:
            # 检查查询和回复中逻辑关系词的匹配
            query_logic_relations = self._extract_logic_relations(query)
            reply_logic_relations = self._extract_logic_relations(reply)
            
            # 如果查询中没有逻辑关系词，返回默认分数
            if not query_logic_relations:
                return 0.5
            
            # 计算逻辑关系匹配度
            matched_relations = 0
            for relation_type, query_words in query_logic_relations.items():
                if relation_type in reply_logic_relations:
                    # 检查具体的逻辑词是否匹配
                    relation_matches = 0
                    for query_word in query_words:
                        if any(query_word in reply_word for reply_word in reply_logic_relations[relation_type]):
                            relation_matches += 1
                    # 如果该类型的逻辑关系有匹配，增加匹配计数
                    if relation_matches > 0:
                        matched_relations += 1
            
            # 逻辑一致性评分 = 匹配的逻辑关系类型数 / 查询中的逻辑关系类型数
            consistency_score = matched_relations / len(query_logic_relations)
            
            return consistency_score
        except Exception as e:
            logger.error(f"评估逻辑一致性失败: {e}")
            return 0.5  # 返回默认分数
            
    def _extract_logic_relations(self, text: str) -> Dict[str, List[str]]:
        """从文本中提取逻辑关系"""
        extracted = defaultdict(list)
        
        for relation_type, words in self.logic_relations.items():
            if isinstance(words, dict):
                # 处理嵌套的逻辑关系结构
                for sub_category, sub_words in words.items():
                    if isinstance(sub_words, list):
                        for word in sub_words:
                            if word in text:
                                extracted[relation_type].append(word)
                    elif isinstance(sub_words, str) and sub_words in text:
                        extracted[relation_type].append(sub_words)
            elif isinstance(words, list):
                # 处理简单的词列表
                for word in words:
                    if word in text:
                        extracted[relation_type].append(word)
            elif isinstance(words, str) and words in text:
                # 处理单个词
                extracted[relation_type].append(words)
        
        return dict(extracted)
            
    def _evaluate_semantic_richness(self, text: str) -> float:
        """评估文本的语义丰富度"""
        try:
            # 计算词汇多样性
            words = list(jieba.cut_for_search(text))
            if not words:
                return 0.0
            
            unique_words = set(words)
            diversity_score = len(unique_words) / len(words)
            
            # 计算逻辑关系词数量
            logic_words = set()
            for relation_type, words_set in self._extract_logic_relations(text).items():
                logic_words.update(words_set)
            
            logic_score = min(1.0, len(logic_words) / max(1, len(unique_words) * 0.1))  # 逻辑词占比的标准化评分
            
            # 计算句子复杂度（简单实现：基于标点符号数量）
            punctuation_count = sum(1 for char in text if char in "。！？,.!?")
            complexity_score = min(1.0, punctuation_count / max(1, len(text) / 20))  # 每20个字符一个标点的标准
            
            # 综合评分
            richness_score = diversity_score * 0.5 + logic_score * 0.3 + complexity_score * 0.2
            
            return richness_score
        except Exception as e:
            logger.error(f"评估语义丰富度失败: {e}")
            return 0.5  # 返回默认分数
            
    def _evaluate_context_coherence(self, reply: str, chat_history: List[str]) -> float:
        """评估回复与上下文的连贯性 - 增强版本，使用语义分析"""
        try:
            if not chat_history:
                return 0.5
            
            # 只考虑最近的几条消息，最新的消息权重更高
            recent_history = chat_history[-5:]
            
            # 1. 计算语义相似度得分
            semantic_similarities = []
            for i, history_msg in enumerate(recent_history):
                # 为较新的消息分配更高的权重
                weight = 1.0 - (i / len(recent_history)) * 0.5
                similarity = self.semantic_analyzer.calculate_semantic_similarity(history_msg, reply)
                semantic_similarities.append(similarity * weight)
            
            if semantic_similarities:
                semantic_score = sum(semantic_similarities) / len(semantic_similarities)
            else:
                semantic_score = 0.5
            
            # 2. 提取关键短语进行匹配（更精确的关键词分析）
            # 合并所有历史消息
            combined_history = " ".join(recent_history)
            
            # 使用语义分析器提取上下文关键短语
            context_key_phrases = self.semantic_analyzer.extract_key_phrases(combined_history, top_n=5)
            context_keywords = set([phrase['phrase'] for phrase in context_key_phrases])
            
            # 提取回复的关键短语
            reply_key_phrases = self.semantic_analyzer.extract_key_phrases(reply, top_n=3)
            reply_keywords = set([phrase['phrase'] for phrase in reply_key_phrases])
            
            # 计算关键短语重叠度
            if context_keywords:
                overlapping_keywords = context_keywords.intersection(reply_keywords)
                keyword_score = len(overlapping_keywords) / len(context_keywords)
            else:
                keyword_score = 0.5
            
            # 3. 主题一致性检查
            # 分析上下文主题
            context_topic = self.semantic_analyzer.classify_topic(combined_history)
            reply_topic = self.semantic_analyzer.classify_topic(reply)
            
            # 主题一致则加分
            if context_topic == reply_topic:
                topic_bonus = 0.2
            else:
                topic_bonus = 0.0
            
            # 4. 矛盾词检查
            contradiction_words = {'但是', '然而', '不过', '可是', '却', '反而', '相反', '并不', '没有', '不'}
            contradiction_count = sum(1 for word in contradiction_words if word in reply)
            contradiction_penalty = contradiction_count * 0.1
            
            # 综合计算最终得分
            # 权重分配：语义相似度(0.4) + 关键词匹配(0.3) + 主题一致(0.2) + 矛盾词惩罚
            final_score = (semantic_score * 0.4) + (keyword_score * 0.3) + topic_bonus
            final_score = max(0.1, final_score - contradiction_penalty)
            
            # 确保分数在合理范围内
            final_score = min(1.0, max(0.1, final_score))
            
            return final_score
        except Exception as e:
            logger.error(f"评估上下文连贯性失败: {e}")
            return 0.5  # 返回默认分数
    
    def _add_training_data_impl(self, message: str, quality_score: float):
        """添加训练数据的核心实现"""
        if not message or not isinstance(message, str):
            logger.warning("无效的训练数据，跳过添加")
            return
        
        # 增加消息计数，可能触发训练
        self.increment_message_count()
        
        # 对高质量消息进行特殊处理
        if quality_score > getattr(self.config, 'high_quality_threshold', 0.7):
            # 高质量消息优先加入训练缓存
            self.high_quality_messages.append(message)
            
            # 限制高质量消息缓存大小
            max_high_quality = getattr(self.config, 'max_high_quality_messages', 1000)
            if len(self.high_quality_messages) > max_high_quality:
                self.high_quality_messages.pop(0)
            
            # 如果高质量消息数量达到阈值，立即触发训练检查
            check_interval = getattr(self.config, 'high_quality_check_interval', 50)
            if len(self.high_quality_messages) % check_interval == 0:
                asyncio.create_task(self._check_and_train_if_needed())
        
        # 所有消息都加入常规训练缓存
        self.training_data_cache.append(message)
        
        # 限制训练缓存大小
        max_cache_size = getattr(self.config, 'max_training_cache_size', 5000)
        if len(self.training_data_cache) > max_cache_size:
            self.training_data_cache.pop(0)
    
    async def add_training_data_async(self, message: str, quality_score: float):
        """异步版本的添加训练数据方法"""
        if not message:
            return
        
        try:
            self._add_training_data_impl(message, quality_score)
        except Exception as e:
            logger.error(f"添加训练数据失败: {e}")
            # 添加重试机制
            try:
                # 短暂延迟后重试
                await asyncio.sleep(0.1)
                self.training_data_cache.append(message)
                logger.info("重试添加训练数据成功")
            except:
                logger.error("重试添加训练数据也失败")
    
    def add_training_data(self, message: str, quality_score: float):
        """同步版本的添加训练数据方法，保持向后兼容"""
        if not message:
            return
        
        try:
            self._add_training_data_impl(message, quality_score)
        except Exception as e:
            logger.error(f"添加训练数据失败: {e}")
            # 添加重试机制 - 同步版本
            try:
                # 不使用await，直接添加
                self.training_data_cache.append(message)
                logger.info("重试添加训练数据成功")
            except:
                logger.error("重试添加训练数据也失败")

    async def _auto_tune_parameters(self, messages: List[str]) -> Dict[str, Any]:
        """增强版自动调优模型参数，增加逻辑推理能力"""
        logger.info("开始增强版自动参数优化")
        best_params = {}
        
        # 对TF-IDF参数进行网格搜索，包括新增的min_df和max_df参数
        try:
            # 准备分层样本数据，确保覆盖不同类型的消息
            sample_size = min(3000, len(messages))
            sample_messages = self._prepare_optimization_samples(messages, sample_size)
            
            # 增强的参数网格，增加min_df和max_df参数
            param_grid = {
                'max_features': self.tuning_params.get('tfidf_max_features', [5000, 10000, 20000]),
                'ngram_range': [(1, n) for n in self.tuning_params.get('tfidf_ngram_range', [1, 2, 3])],
                'min_df': self.tuning_params.get('tfidf_min_df', [0.001, 0.005, 0.01]),
                'max_df': self.tuning_params.get('tfidf_max_df', [0.9, 0.95, 1.0])
            }
            
            # 并行参数评估准备
            param_combinations = []
            for max_features in param_grid['max_features']:
                for ngram_range in param_grid['ngram_range']:
                    for min_df in param_grid['min_df']:
                        for max_df in param_grid['max_df']:
                            param_combinations.append({
                                'max_features': max_features,
                                'ngram_range': ngram_range,
                                'min_df': min_df,
                                'max_df': max_df
                            })
            
            # 分批评估参数以避免资源耗尽
            batch_size = 10
            param_batches = [param_combinations[i:i+batch_size] for i in range(0, len(param_combinations), batch_size)]
            
            best_score = -1
            best_params = None
            
            for batch_idx, param_batch in enumerate(param_batches):
                logger.info(f"评估参数批次 {batch_idx+1}/{len(param_batches)}")
                
                # 并行评估本批次参数
                batch_results = await asyncio.gather(
                    *[self._evaluate_parameters(params, sample_messages) for params in param_batch]
                )
                
                # 寻找本批次最佳参数
                for i, (score, params) in enumerate(zip(batch_results, param_batch)):
                    if score > best_score:
                        best_score = score
                        best_params = params
            
            # 添加聚类参数评估
            cluster_params = await self._evaluate_clustering(sample_messages, best_params)
            best_params.update(cluster_params)
            
            logger.info(f"参数调优完成，最佳参数: {best_params}")
            
            # 记录详细的优化历史
            self.optimization_history.append({
                'timestamp': time.time(),
                'params': best_params,
                'score': best_score,
                'sample_size': sample_size,
                'optimization_type': 'enhanced_grid_search'
            })
            
            # 限制优化历史长度
            max_history = getattr(self.config, 'max_optimization_history', 100)
            if len(self.optimization_history) > max_history:
                self.optimization_history.pop(0)
                
            # 基于历史优化记录进行元学习
            if len(self.optimization_history) > 5:
                self._learn_from_optimization_history()
                
        except Exception as e:
            logger.error(f"参数优化失败: {e}")
            # 如果优化失败，返回默认参数，包括新增的min_df和max_df
            best_params = {
                'tfidf_max_features': self.config.tfidf_max_features,
                'tfidf_ngram_range': self.config.tfidf_ngram_range,
                'tfidf_min_df': getattr(self.config, 'tfidf_min_df', 0.001),
                'tfidf_max_df': getattr(self.config, 'tfidf_max_df', 0.95)
            }
        
        return best_params
        
    def _prepare_optimization_samples(self, messages: List[str], sample_size: int) -> List[str]:
        """准备用于参数优化的样本数据，确保样本多样性"""
        if len(messages) <= sample_size:
            return messages
            
        # 简单的分层采样策略
        chunk_size = max(1, len(messages) // sample_size)
        samples = []
        
        # 首先选择高质量消息
        high_quality = [msg for msg in messages if self._evaluate_content_quality(msg) > 0.7]
        if high_quality:
            hq_sample_size = min(len(high_quality), sample_size // 3)
            samples.extend(random.sample(high_quality, hq_sample_size))
            
        # 再从剩余消息中随机选择
        remaining_size = sample_size - len(samples)
        if remaining_size > 0 and len(messages) > len(high_quality):
            other_messages = [msg for msg in messages if msg not in high_quality]
            samples.extend(random.sample(other_messages, min(remaining_size, len(other_messages))))
            
        # 如果样本不足，从原始消息中补充
        if len(samples) < sample_size:
            additional = min(sample_size - len(samples), len(messages))
            samples.extend(random.sample(messages, additional))
            
        return samples
        
    async def _evaluate_parameters(self, params: Dict, messages: List[str]) -> float:
        """评估参数组合的性能"""
        try:
            # 创建并训练向量器
            test_vectorizer = TfidfVectorizer(
                tokenizer=lambda x: list(jieba.cut_for_search(x)),
                **params
            )
            
            # 限制处理消息数量以提高效率
            process_size = min(2000, len(messages))
            process_messages = messages[:process_size]
            
            vectors = test_vectorizer.fit_transform(process_messages)
            
            # 基础评估指标
            vocab_size = len(test_vectorizer.vocabulary_)
            sparsity = 1 - (vectors.nnz / (vectors.shape[0] * vectors.shape[1]))
            
            # 逻辑一致性评分 - 评估向量器对逻辑关系词的处理能力
            logic_score = self._evaluate_logic_consistency(test_vectorizer)
            
            # 语义丰富度评分
            semantic_score = self._evaluate_semantic_richness(vocab_size, params)
            
            # 综合评分：平衡多种因素
            score = (
                min(vocab_size / 20000, 1.0) * 0.3 +  # 词汇表大小 (30%)
                (1 - sparsity) * 0.2 +                 # 稀疏性 (20%)
                logic_score * 0.3 +                    # 逻辑一致性 (30%) - 增加权重以增强逻辑性
                semantic_score * 0.2                   # 语义丰富度 (20%)
            )
            
            return score
        except Exception as e:
            logger.warning(f"参数评估失败: {e}")
            return 0
            
    def _evaluate_logic_consistency(self, vectorizer: TfidfVectorizer) -> float:
        """评估向量器对逻辑关系词的处理能力"""
        # 检查向量器是否包含逻辑关系词
        logic_words_found = 0
        total_logic_words = 0
        
        for relation_type, words in self.logic_relations.items():
            total_logic_words += len(words)
            for word in words:
                if word in vectorizer.vocabulary_:
                    logic_words_found += 1
        
        # 计算逻辑关系词覆盖率
        if total_logic_words == 0:
            return 0.5  # 默认值
        
        coverage = min(logic_words_found / total_logic_words, 1.0)
        
        # 检查最近回复的逻辑一致性
        recent_logic_score = 0
        if hasattr(self, 'recent_replies') and self.recent_replies:
            recent_logic_scores = []
            for reply_info in self.recent_replies[-5:]:  # 检查最近5条回复
                if 'logic_score' in reply_info:
                    recent_logic_scores.append(reply_info['logic_score'])
            if recent_logic_scores:
                recent_logic_score = sum(recent_logic_scores) / len(recent_logic_scores)
        
        # 综合逻辑评分
        return coverage * 0.7 + recent_logic_score * 0.3
        
    def _evaluate_semantic_richness(self, vocab_size: int, params: Dict) -> float:
        """评估语义丰富度"""
        # 基础分：词汇表大小适中
        base_score = min(max(vocab_size / 5000, 0.5), 1.0) if vocab_size > 0 else 0.5
        
        # 加分项：使用了n-gram特征
        if params.get('ngram_range', (1,1))[1] > 1:
            base_score += 0.1
        
        # 加分项：适当的文档频率过滤
        min_df = params.get('min_df', 0)
        max_df = params.get('max_df', 1.0)
        if 0.0005 < min_df < 0.02 and 0.8 < max_df < 0.99:
            base_score += 0.1
        
        return min(base_score, 1.0)
        
    async def _evaluate_clustering(self, messages: List[str], base_params: Dict) -> Dict:
        """评估聚类参数"""
        try:
            logger.info("评估聚类参数")
            
            # 创建基于最佳TF-IDF参数的向量器
            vectorizer = TfidfVectorizer(
                tokenizer=lambda x: list(jieba.cut_for_search(x)),
                max_features=base_params.get('max_features', 10000),
                ngram_range=base_params.get('ngram_range', (1,2)),
                min_df=base_params.get('min_df', 0.001),
                max_df=base_params.get('max_df', 0.95)
            )
            
            # 限制处理消息数量
            process_size = min(1000, len(messages))
            vectors = vectorizer.fit_transform(messages[:process_size])
            
            # 评估不同的聚类数量
            best_n_clusters = getattr(self.config, 'default_clusters', 20)
            best_silhouette_score = -1
            
            # 尝试不同的聚类数量
            for n_clusters in [10, 20, 30, 50]:
                try:
                    if vectors.shape[0] > n_clusters:
                        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
                        labels = kmeans.fit_predict(vectors)
                        
                        # 计算轮廓系数评估聚类质量
                        silhouette_avg = silhouette_score(vectors, labels)
                        
                        if silhouette_avg > best_silhouette_score:
                            best_silhouette_score = silhouette_avg
                            best_n_clusters = n_clusters
                except Exception as e:
                    logger.warning(f"聚类评估失败 (n_clusters={n_clusters}): {e}")
                    continue
            
            logger.info(f"最佳聚类数量: {best_n_clusters}, 轮廓系数: {best_silhouette_score:.4f}")
            
            return {
                'n_clusters': best_n_clusters,
                'silhouette_score': best_silhouette_score
            }
        except Exception as e:
            logger.error(f"聚类参数评估失败: {e}")
            return {
                'n_clusters': getattr(self.config, 'default_clusters', 20)
            }
            
    def _learn_from_optimization_history(self):
        """从优化历史中学习，改进未来的参数优化"""
        try:
            # 分析历史最佳参数的趋势
            recent_history = self.optimization_history[-5:]
            if len(recent_history) < 3:
                return
                
            # 提取历史参数趋势
            param_trends = defaultdict(list)
            for record in recent_history:
                for param, value in record['params'].items():
                    if isinstance(value, (int, float)):
                        param_trends[param].append(value)
                        
            # 更新默认参数范围，向历史最佳值靠近
            for param, values in param_trends.items():
                if param.startswith('tfidf_'):
                    avg_value = sum(values) / len(values)
                    # 例如，对于max_features参数，调整未来的搜索范围
                    if param == 'tfidf_max_features':
                        new_min = max(1000, int(avg_value * 0.8))
                        new_max = min(50000, int(avg_value * 1.2))
                        self.tuning_params['tfidf_max_features'] = [new_min, avg_value, new_max]
                        
            logger.info("从优化历史中学习完成，更新了参数搜索范围")
        except Exception as e:
            logger.error(f"从优化历史中学习失败: {e}")
    
    async def _train_personalization_model(self):
        """训练用户个性化模型 - 增强版，包含情感偏好、主题偏好和互动模式"""
        try:
            import sqlite3
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                # 获取用户消息数据和反馈数据
                cursor.execute("""
                    SELECT cl.user_id, cl.message, cl.quality_score, cl.timestamp,
                           uf.feedback_score, uf.feedback_type
                    FROM chat_logs cl
                    LEFT JOIN user_feedback uf ON cl.user_id = uf.user_id AND cl.timestamp = uf.timestamp
                    WHERE cl.quality_score > 0.5
                    ORDER BY cl.user_id, cl.timestamp
                """)
                user_data = cursor.fetchall()
                
                # 按用户ID分组
                user_groups = defaultdict(list)
                for row in user_data:
                    user_id, message, quality_score, timestamp, feedback_score, feedback_type = row
                    if quality_score > getattr(self.config, 'personalization_min_score', 0.7):
                        # 确保timestamp是数值类型（整数或浮点数）
                        try:
                            timestamp_value = float(timestamp)
                        except (ValueError, TypeError):
                            # 如果无法转换，使用当前时间戳
                            timestamp_value = time.time()
                        
                        user_groups[user_id].append({
                            'message': message,
                            'quality_score': quality_score,
                            'timestamp': timestamp_value,
                            'feedback_score': feedback_score if feedback_score is not None else 0,
                            'feedback_type': feedback_type
                        })
                
                # 为活跃用户创建增强版个性化模型
                for user_id, user_messages in user_groups.items():
                    if len(user_messages) >= getattr(self.config, 'personalization_min_messages', 20):
                        try:
                            # 提取用户消息文本
                            messages = [msg['message'] for msg in user_messages]
                            
                            # 创建用户个性化向量器
                            user_vectorizer = TfidfVectorizer(
                                tokenizer=lambda x: list(jieba.cut_for_search(x)),
                                max_features=3000,
                                ngram_range=(1, 2)
                            )
                            user_vectorizer.fit(messages)
                            
                            # 提取用户特征词
                            feature_names = np.array(user_vectorizer.get_feature_names_out())
                            if len(feature_names) > 0:
                                # 1. 计算用户偏好的关键词
                                user_profiles = []
                                for msg in messages[:30]:  # 取前30条消息计算
                                    if msg.strip():
                                        try:
                                            vec = user_vectorizer.transform([msg])
                                            top_indices = vec.indices[vec.data.argsort()[-7:][::-1]] if vec.nnz > 0 else []
                                            user_profiles.extend(feature_names[top_indices])
                                        except:
                                            pass
                                
                                # 统计用户高频词
                                word_freq = defaultdict(int)
                                for word in user_profiles:
                                    word_freq[word] += 1
                                
                                # 2. 分析用户情感偏好
                                sentiment_analysis = [self.semantic_analyzer.analyze_sentiment(msg) for msg in messages]
                                sentiment_scores = [sa['score'] for sa in sentiment_analysis]
                                avg_sentiment = sum(sentiment_scores) / len(sentiment_scores)
                                sentiment_preference = 'positive' if avg_sentiment > 0.2 else 'negative' if avg_sentiment < -0.2 else 'neutral'
                                
                                # 3. 分析用户主题偏好
                                topic_analysis = [self.semantic_analyzer.classify_topic(msg) for msg in messages]
                                topic_freq = defaultdict(int)
                                for topic in topic_analysis:
                                    if topic != 'unknown':
                                        topic_freq[topic] += 1
                                
                                # 获取用户最感兴趣的主题
                                top_topics = sorted(topic_freq.items(), key=lambda x: x[1], reverse=True)[:3]
                                
                                # 4. 分析用户互动模式
                                interaction_times = [msg['timestamp'] for msg in user_messages]
                                if len(interaction_times) > 1:
                                    time_diffs = [interaction_times[i] - interaction_times[i-1] for i in range(1, len(interaction_times))]
                                    avg_response_time = sum(time_diffs) / len(time_diffs)
                                else:
                                    avg_response_time = 0
                                
                                # 分析用户反馈模式
                                positive_feedback_count = sum(1 for msg in user_messages if msg['feedback_score'] >= 4)
                                negative_feedback_count = sum(1 for msg in user_messages if msg['feedback_score'] <= 2)
                                feedback_ratio = positive_feedback_count / (positive_feedback_count + negative_feedback_count + 1)
                                
                                # 保存增强版用户画像
                                self.user_profiles[user_id] = {
                                    'keywords': {word: freq for word, freq in sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:15]},
                                    'sentiment_preference': sentiment_preference,
                                    'sentiment_score': avg_sentiment,
                                    'topic_preferences': dict(top_topics),
                                    'avg_response_time': avg_response_time,
                                    'feedback_ratio': feedback_ratio,
                                    'interaction_count': len(user_messages),
                                    'last_interaction': max(msg['timestamp'] for msg in user_messages)
                                }
                                
                                logger.debug(f"已创建用户 {user_id} 的增强版个性化模型")
                                logger.debug(f"  关键词: {list(self.user_profiles[user_id]['keywords'].keys())[:10]}")
                                logger.debug(f"  情感偏好: {sentiment_preference} (得分: {avg_sentiment:.2f})")
                                logger.debug(f"  主题偏好: {[topic for topic, _ in top_topics]}")
                        except Exception as e:
                            logger.error(f"创建用户 {user_id} 的个性化模型失败: {e}")
                            
            # 限制用户配置文件数量
            max_profiles = getattr(self.config, 'max_user_profiles', 100)
            if len(self.user_profiles) > max_profiles:
                # 按用户互动次数排序，保留最活跃的用户
                active_users = sorted(
                    self.user_profiles.items(),
                    key=lambda x: x[1]['interaction_count'],
                    reverse=True
                )[:max_profiles]
                self.user_profiles = dict(active_users)
                
        except Exception as e:
            logger.error(f"训练用户个性化模型失败: {e}")
    
    def _calculate_context_coherence_score(self, query: str, reply: str) -> float:
        """计算上下文连贯性评分"""
        try:
            # 简单实现：检查回复是否包含查询中的关键词
            query_words = set(jieba.cut_for_search(query))
            reply_words = set(jieba.cut_for_search(reply))
            common_words = query_words.intersection(reply_words)
            
            if not query_words:
                return 0.5
            
            # 基础连贯性得分
            coherence_score = len(common_words) / len(query_words)
            
            # 检查是否有否定关系（降低得分）
            negations = {'不', '没', '无', '非', '未', '否', '不是', '没有'}
            negation_in_reply = any(word in reply_words for word in negations)
            if negation_in_reply:
                # 否定通常表示上下文转变，但不一定是坏事
                coherence_score *= 0.8
            
            # 检查是否有连接词（提高得分）
            connectives = {'所以', '因此', '而且', '但是', '不过', '然而', '此外', '另外'}
            connective_in_reply = any(word in reply_words for word in connectives)
            if connective_in_reply:
                coherence_score = min(1.0, coherence_score * 1.1)
            
            return coherence_score
        except Exception as e:
            logger.error(f"计算上下文连贯性失败: {e}")
            return 0.5
    
    def _cleanup_old_caches(self):
        """清理过期的缓存数据"""
        try:
            # 清理训练数据缓存（保留最新的）
            if hasattr(self, 'training_data_cache'):
                max_cache_size = getattr(self.config, 'max_training_cache_size', 5000)
                if len(self.training_data_cache) > max_cache_size * 0.8:
                    # 只保留最新的80%
                    self.training_data_cache = self.training_data_cache[-int(max_cache_size * 0.8):]
                    logger.debug(f"已清理训练数据缓存，当前大小: {len(self.training_data_cache)}")
            
            # 清理高质量消息缓存
            if hasattr(self, 'high_quality_messages'):
                max_high_quality = getattr(self.config, 'max_high_quality_messages', 1000)
                if len(self.high_quality_messages) > max_high_quality * 0.8:
                    self.high_quality_messages = self.high_quality_messages[-int(max_high_quality * 0.8):]
                    logger.debug(f"已清理高质量消息缓存，当前大小: {len(self.high_quality_messages)}")
            
            # 清理上下文记忆
            if hasattr(self, 'context_memory'):
                # 移除长时间没有活动的用户上下文
                current_time = time.time()
                inactive_threshold = getattr(self.config, 'context_inactive_threshold', 3600)  # 1小时
                
                # 简化实现，实际项目中应该记录每个上下文条目的时间戳
                pass
                
        except Exception as e:
            logger.error(f"清理缓存失败: {e}")
    
    async def get_personalized_reply(self, user_id: str, message: str, chat_history: List[str] = None) -> Optional[str]:
        """获取个性化回复 - 增强版，结合上下文记忆和用户画像"""
        try:
            # 检查用户是否有个性化配置
            if user_id not in self.user_profiles:
                return None
            
            user_profile = self.user_profiles[user_id]
            if not user_profile or 'keywords' not in user_profile:
                return None
            
            # 分析当前消息
            current_sentiment = self.semantic_analyzer.analyze_sentiment(message)
            current_topic = self.semantic_analyzer.classify_topic(message)
            message_words = set(jieba.cut_for_search(message))
            
            # 1. 提取用户偏好关键词并计算匹配度
            user_keywords = set(user_profile['keywords'].keys())
            common_keywords = user_keywords.intersection(message_words)
            keyword_match_score = len(common_keywords) / len(user_keywords) if user_keywords else 0
            
            # 2. 分析主题偏好匹配度
            topic_match_score = 0
            if current_topic != 'unknown' and user_profile['topic_preferences']:
                if current_topic in user_profile['topic_preferences']:
                    topic_match_score = user_profile['topic_preferences'][current_topic] / sum(user_profile['topic_preferences'].values())
            
            # 3. 综合匹配度检查
            if keyword_match_score < 0.1 and topic_match_score < 0.1:
                return None
            
            # 4. 从数据库获取候选回复
            import sqlite3
            
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                
                # 构建搜索条件 - 结合关键词和主题
                conditions = []
                params = [self.config.message_quality_threshold]
                
                if common_keywords:
                    keyword_conditions = " OR ".join([f"message LIKE '%{kw}%'" for kw in common_keywords])
                    conditions.append(f"({keyword_conditions})")
                
                if current_topic != 'unknown':
                    conditions.append(f"(message LIKE '%{current_topic}%' OR reply LIKE '%{current_topic}%')")
                
                if not conditions:
                    return None
                
                query = f"""
                SELECT message, reply, quality_score FROM chat_logs 
                WHERE quality_score >= ? AND ({' OR '.join(conditions)})
                ORDER BY quality_score DESC LIMIT 20
                """
                
                cursor.execute(query, tuple(params))
                candidates = [{'query': row[0], 'reply': row[1], 'quality_score': row[2]} for row in cursor.fetchall()]
                
                if not candidates:
                    return None
            
            # 5. 为候选回复评分 - 综合考虑多种因素
            scored_candidates = []
            for candidate in candidates:
                score = candidate['quality_score'] * 0.5
                
                # 关键词匹配得分
                candidate_words = set(jieba.cut_for_search(candidate['reply']))
                candidate_common_keywords = user_keywords.intersection(candidate_words)
                candidate_keyword_score = len(candidate_common_keywords) / len(user_keywords) if user_keywords else 0
                score += candidate_keyword_score * 0.2
                
                # 主题一致性得分
                candidate_topic = self.semantic_analyzer.classify_topic(candidate['reply'])
                if current_topic != 'unknown' and candidate_topic == current_topic:
                    score += 0.15
                
                # 情感匹配得分
                candidate_sentiment = self.semantic_analyzer.analyze_sentiment(candidate['reply'])
                if user_profile['sentiment_preference'] == 'positive' and candidate_sentiment['score'] > 0.2:
                    score += 0.1
                elif user_profile['sentiment_preference'] == 'negative' and -0.3 < candidate_sentiment['score'] < 0.5:
                    score += 0.1
                
                # 上下文一致性得分
                if chat_history:
                    context_score = self._evaluate_context_coherence(candidate['reply'], chat_history)
                    score += context_score * 0.05
                
                scored_candidates.append((score, candidate['reply']))
            
            # 6. 选择得分最高的回复
            if scored_candidates:
                best_reply = sorted(scored_candidates, key=lambda x: x[0], reverse=True)[0][1]
                
                # 7. 根据用户反馈调整回复
                if user_profile['feedback_ratio'] < 0.3:  # 如果用户经常给负面反馈
                    # 使回复更加保守和正式
                    best_reply = self._make_reply_more_conservative(best_reply)
                elif user_profile['feedback_ratio'] > 0.8:  # 如果用户经常给正面反馈
                    # 使回复更加个性化和亲切
                    best_reply = self._make_reply_more_personalized(best_reply, user_profile)
                
                # 8. 记录个性化评分
                personalization_score = (keyword_match_score + topic_match_score) / 2
                self.record_metric('personalization_score', personalization_score, {
                    'user_id': user_id,
                    'query': message[:50],
                    'reply': best_reply[:50],
                    'keyword_match': keyword_match_score,
                    'topic_match': topic_match_score
                })
                
                return best_reply
            
            return None
        except Exception as e:
            logger.error(f"获取个性化回复失败: {e}")
            return None
            
    def _make_reply_more_conservative(self, reply: str) -> str:
        """使回复更加保守和正式"""
        # 将一些口语化表达替换为更正式的表达
        formal_replacements = {
            '吧': '',
            '啦': '',
            '哦': '',
            '呢': '',
            '哇': '',
            '哈哈': '',
            '嘿嘿': '',
            '嗯': '是的',
            '是的呀': '是的',
            '好的呀': '好的',
            '可以呀': '可以',
            '没问题呀': '没问题'
        }
        
        for informal, formal in formal_replacements.items():
            reply = reply.replace(informal, formal)
        
        # 确保回复完整
        if not reply.endswith(('.', '!', '?', '。', '！', '？')):
            reply += '。'
        
        return reply
        
    def _make_reply_more_personalized(self, reply: str, user_profile: Dict) -> str:
        """使回复更加个性化和亲切"""
        # 根据用户情感偏好添加个性化表达
        if user_profile['sentiment_preference'] == 'positive':
            personalization_phrases = ['😊', '很高兴为您服务！', '希望这对您有帮助！', '您觉得这样可以吗？']
        elif user_profile['sentiment_preference'] == 'negative':
            personalization_phrases = ['别担心', '慢慢来', '我会尽力帮助您', '您还有其他问题吗？']
        else:
            personalization_phrases = ['希望这对您有帮助', '您需要进一步的信息吗？', '有任何问题随时问我']
        
        # 随机选择一个个性化短语添加到回复末尾
        if not reply.endswith(tuple(['😊', '。', '！', '？', '.', '!', '?'])):
            reply += ' ' + random.choice(personalization_phrases)
        
        return reply
    
    async def update_context_memory(self, user_id: str, message: str, reply: str = None):
        """更新对话上下文记忆 - 增强版本，包含主题和情感分析"""
        try:
            if not hasattr(self, 'context_memory'):
                self.context_memory = defaultdict(lambda: deque(maxlen=self.config.context_window_size))
            
            # 使用语义分析器分析用户消息
            user_sentiment = self.semantic_analyzer.analyze_sentiment(message)
            user_topics = self.semantic_analyzer.extract_key_phrases(message, top_n=2)
            user_topic = self.semantic_analyzer.classify_topic(message)
            
            # 分析机器人回复（如果有）
            reply_sentiment = None
            reply_topics = []
            reply_topic = None
            reply_quality = None
            
            if reply:
                reply_sentiment = self.semantic_analyzer.analyze_sentiment(reply)
                reply_topics = self.semantic_analyzer.extract_key_phrases(reply, top_n=2)
                reply_topic = self.semantic_analyzer.classify_topic(reply)
                # 评估回复质量
                reply_quality = await self.evaluate_reply_quality(message, reply)
            
            # 检查主题一致性
            topic_consistency = 1.0 if user_topic == reply_topic else 0.0
            
            # 存储增强的上下文信息
            context_item = {
                'timestamp': time.time(),
                'user_message': message[:200],  # 限制长度
                'user_sentiment': user_sentiment['sentiment'],
                'user_sentiment_score': user_sentiment['score'],
                'user_topics': [topic['phrase'] for topic in user_topics],
                'user_topic': user_topic,
                'bot_reply': reply[:200] if reply else None,
                'reply_sentiment': reply_sentiment['sentiment'] if reply_sentiment else None,
                'reply_sentiment_score': reply_sentiment['score'] if reply_sentiment else None,
                'reply_topics': [topic['phrase'] for topic in reply_topics],
                'reply_topic': reply_topic,
                'reply_quality': reply_quality,
                'topic_consistency': topic_consistency
            }
            
            self.context_memory[user_id].append(context_item)
            
            # 记录上下文更新
            logger.debug(f"已更新用户 {user_id} 的对话上下文，当前长度: {len(self.context_memory[user_id])}")
            
        except Exception as e:
            logger.error(f"更新上下文记忆失败: {e}")
    
    def get_context_summary(self, user_id: str) -> str:
        """获取对话上下文摘要 - 增强版本，包含主题、情感和对话趋势"""
        try:
            if not hasattr(self, 'context_memory') or user_id not in self.context_memory:
                return ""
            
            context = self.context_memory[user_id]
            if not context:
                return ""
            
            # 提取所有用户消息和机器人回复
            user_messages = [item['user_message'] for item in context if item['user_message']]
            bot_replies = [item['bot_reply'] for item in context if item['bot_reply']]
            
            if not user_messages:
                return ""
            
            # 合并所有对话内容
            all_text = " ".join(user_messages + bot_replies)
            
            # 使用已有的语义分析器（避免重复创建实例）
            # 提取关键短语
            key_phrases = self.semantic_analyzer.extract_key_phrases(all_text, top_n=5)
            
            if not key_phrases:
                return ""
            
            # 分析对话主题
            dialogue_topic = self.semantic_analyzer.classify_topic(all_text)
            
            # 分析情感趋势
            sentiments = [item['user_sentiment'] for item in context if 'user_sentiment' in item]
            if sentiments:
                positive_count = sentiments.count('positive')
                negative_count = sentiments.count('negative')
                neutral_count = sentiments.count('neutral')
                
                # 确定主导情感
                if positive_count > negative_count and positive_count > neutral_count:
                    dominant_sentiment = "积极"
                elif negative_count > positive_count and negative_count > neutral_count:
                    dominant_sentiment = "消极"
                else:
                    dominant_sentiment = "中性"
            else:
                dominant_sentiment = "未知"
            
            # 提取最近的对话主题
            recent_topics = set()
            for item in reversed(context):
                if 'user_topics' in item and item['user_topics']:
                    recent_topics.update(item['user_topics'])
                if 'reply_topics' in item and item['reply_topics']:
                    recent_topics.update(item['reply_topics'])
                if len(recent_topics) >= 3:
                    break
            
            # 构建增强摘要
            summary_parts = []
            summary_parts.append(f"对话主题: {dialogue_topic}")
            summary_parts.append(f"主导情感: {dominant_sentiment}")
            summary_parts.append(f"最近讨论: {', '.join(list(recent_topics)[:5])}")
            
            # 添加对话轮次信息
            total_turns = len(user_messages)
            summary_parts.append(f"对话轮次: {total_turns}")
            
            # 合并摘要部分
            summary = " | ".join(summary_parts)
            return summary[:150]  # 适当增加长度限制
            
        except Exception as e:
            logger.error(f"获取上下文摘要失败: {e}")
            return ""
            
    # 重写_advanced_training方法以包含新功能
    async def _advanced_training(self, messages: List[str]):
        """执行高级训练算法"""
        try:
            # 1. 执行自动参数优化
            if self.config.auto_tuning_enabled and (self.message_count_since_last_training > self.config.tuning_min_messages or 
                                                  time.time() - self.last_training_time > self.config.tuning_interval):
                tuned_params = await self._auto_tune_parameters(messages)
                logger.info(f"自动参数优化完成，最佳参数: {tuned_params}")
                # 更新配置
                for param, value in tuned_params.items():
                    setattr(self.config, param, value)
            
            # 2. 训练TF-IDF向量器（增强版）
            self._train_enhanced_tfidf(messages)
            
            # 3. 训练K-means聚类模型
            self._train_clustering_model(messages)
            
            # 4. 训练用户个性化模型
            await self._train_personalization_model()
            
            # 5. 保存训练结果
            self._save_model_state()
            
            # 6. 清理过期缓存
            self._cleanup_old_caches()
        except Exception as e:
            logger.error(f"高级训练失败: {e}")
            raise

# 高级语义分析器
class AdvancedSemanticAnalyzer:
    """高级语义分析器，提供更复杂的文本分析功能"""
    def __init__(self):
        # 初始化情感词典和其他资源
        self._init_resources()
        # 初始化词向量模型
        self._init_word_vectors()
        # 初始化常识知识库
        self._init_knowledge_base()
        # 初始化逻辑推理规则
        self._init_logical_rules()
    
    def _init_resources(self):
        """初始化分析资源"""
        # 情感词汇表（简化版）
        self.positive_words = {
            '好': 1.0, '优秀': 2.0, '棒': 1.5, '开心': 1.2, '高兴': 1.2,
            '喜欢': 1.0, '满意': 1.5, '成功': 1.8, '精彩': 1.5, '赞美': 1.2,
            '不错': 0.8, '真好': 1.5, '太棒了': 2.0, '完美': 2.0
        }
        
        self.negative_words = {
            '不好': -1.0, '糟糕': -2.0, '差': -1.5, '失望': -1.2, '难过': -1.2,
            '讨厌': -1.0, '不满意': -1.5, '失败': -1.8, '无聊': -1.5, '批评': -1.2,
            '错误': -1.0, '坏': -1.5, '太差了': -2.0, '糟糕透了': -2.0
        }
        
        # 程度副词
        self.intensifiers = {
            '很': 1.5, '非常': 2.0, '特别': 1.8, '极其': 2.5, '太': 1.8,
            '有点': 0.5, '稍微': 0.3, '略微': 0.2
        }
        
        # 否定词
        self.negations = {'不', '没', '无', '非', '未', '否'}
        
        # 主题分类关键词
        self.topic_keywords = {
            'technology': {'技术', '编程', '代码', '软件', '电脑', '互联网', 'AI', '人工智能', '算法', '数据'}, 
            'entertainment': {'游戏', '电影', '音乐', '娱乐', '明星', '综艺', '动漫', '小说', '追剧'}, 
            'daily_life': {'生活', '日常', '工作', '学习', '吃饭', '睡觉', '旅行', '购物', '天气'}, 
            'emotion': {'开心', '难过', '生气', '高兴', '伤心', '焦虑', '压力', '愉快', '烦恼'}, 
            'question': {'什么', '怎么', '为什么', '何时', '哪里', '谁', '如何', '是否', '吗', '呢'}
        }
    
    def _init_word_vectors(self):
        """初始化词向量模型"""
        self.word2vec_model = None
        self.word_vector_size = 100  # 默认向量大小
        
        # 尝试加载预训练词向量模型
        try:
            # 检查是否存在本地词向量文件
            model_path = os.path.join(os.path.dirname(__file__), 'data', 'word2vec.model')
            if os.path.exists(model_path):
                self.word2vec_model = Word2Vec.load(model_path)
                logger.info("成功加载本地词向量模型")
            else:
                # 如果没有本地模型，可以使用gensim的预训练模型或创建一个简单的模型
                logger.info("未找到本地词向量模型，将使用简单的语义相似度计算")
        except Exception as e:
            logger.error(f"加载词向量模型失败: {e}")
    
    def _init_knowledge_base(self):
        """初始化常识知识库"""
        # 常识知识库（简化版）
        self.common_knowledge = {
            # 时间常识
            'time': {
                '一天有24小时': '是的，一天有24小时，分为白天和黑夜',
                '一年有365天': '是的，平年有365天，闰年有366天',
                '一周有7天': '是的，一周有7天，分别是星期一到星期日',
                '春节是中国的传统节日': '是的，春节是中国最重要的传统节日，通常在农历正月初一',
            },
            # 地理常识
            'geography': {
                '中国的首都是北京': '是的，中国的首都是北京',
                '地球是圆的': '是的，地球是一个近似球体的行星',
                '太阳从东方升起': '是的，由于地球自西向东自转，太阳看起来从东方升起，西方落下',
                '海洋是蓝色的': '是的，海洋看起来是蓝色的，这是因为水吸收了其他颜色的光，反射了蓝色光',
            },
            # 科学常识
            'science': {
                '水的化学式是H2O': '是的，水的化学式是H2O，表示一个水分子由两个氢原子和一个氧原子组成',
                '人类需要呼吸氧气': '是的，人类和大多数生物需要呼吸氧气来维持生命',
                '植物需要阳光进行光合作用': '是的，植物通过光合作用将阳光转化为能量',
                '重力使物体下落': '是的，地球的重力使物体向地面下落',
            },
            # 生活常识
            'life': {
                '吃饭是为了获取能量': '是的，食物提供人体所需的能量和营养物质',
                '睡眠对健康很重要': '是的，充足的睡眠对身体健康和大脑功能都很重要',
                '运动有助于保持健康': '是的，定期运动有助于保持身体健康和心理健康',
                '喝水对身体有益': '是的，水是人体的重要组成部分，保持水分对健康至关重要',
            },
            # 文化常识
            'culture': {
                '孔子是中国古代的思想家': '是的，孔子是中国古代伟大的思想家、教育家，儒家学派的创始人',
                '四大发明是中国古代的重要发明': '是的，中国古代的四大发明是造纸术、印刷术、火药和指南针',
                '《红楼梦》是中国古典文学名著': '是的，《红楼梦》是中国古典文学四大名著之一，作者是曹雪芹',
                '京剧是中国的传统戏曲': '是的，京剧是中国的国粹，是中国传统戏曲的代表',
            }
        }
        
        # 知识库索引，用于快速查找
        self.knowledge_index = {}
        for domain, knowledge_items in self.common_knowledge.items():
            for question, answer in knowledge_items.items():
                # 提取关键词作为索引
                keywords = jieba.cut_for_search(question)
                for keyword in keywords:
                    if len(keyword) > 1:  # 只索引长度大于1的词
                        if keyword not in self.knowledge_index:
                            self.knowledge_index[keyword] = []
                        self.knowledge_index[keyword].append((domain, question, answer))
        
        logger.info("常识知识库初始化完成，包含{}个领域的常识".format(len(self.common_knowledge)))
    
    def _init_logical_rules(self):
        """初始化逻辑推理规则"""
        # 逻辑推理规则库
        self.logical_rules = {
            # 因果推理
            'causal': {
                '规则1': '如果A导致B，那么B发生时可能与A有关',
                '规则2': '如果A是B的必要条件，那么没有A就没有B',
                '规则3': '如果A是B的充分条件，那么有A就有B',
            },
            # 类比推理
            'analogy': {
                '规则1': '如果A和B在某些方面相似，那么它们在其他方面也可能相似',
                '规则2': '如果A可以解决B问题，那么与B相似的问题可能也可以用A解决',
            },
            # 演绎推理
            'deduction': {
                '规则1': '如果所有A都是B，且C是A，那么C是B',
                '规则2': '如果A或B为真，且A为假，那么B为真',
            },
            # 归纳推理
            'induction': {
                '规则1': '如果多个实例都表现出某种规律，那么该规律可能普遍适用',
                '规则2': '如果过去的事件遵循某种模式，那么未来的事件可能也遵循该模式',
            },
        }
        
        # 逻辑连接词
        self.logical_connectives = {
            '因果': ['因为', '所以', '因此', '由于', '导致', '结果', '使得'],
            '转折': ['但是', '然而', '不过', '可是', '却', '反而'],
            '递进': ['而且', '并且', '不仅', '还', '甚至', '更'],
            '条件': ['如果', '假如', '假设', '要是', '只要', '除非', '无论'],
            '并列': ['和', '与', '以及', '同时', '既...又', '一方面...另一方面'],
            '选择': ['或者', '要么', '不是...就是', '与其...不如'],
            '总结': ['总之', '综上所述', '总的来说', '一句话', '说到底'],
        }
        
        logger.info("逻辑推理规则初始化完成")
    
    def analyze_sentiment(self, text: str) -> Dict[str, float]:
        """分析文本情感"""
        if not text:
            return {'positive': 0.0, 'negative': 0.0, 'score': 0.0, 'sentiment': 'neutral'}
        
        # 分词
        words = list(jieba.cut(text))
        
        positive_score = 0.0
        negative_score = 0.0
        
        # 情感分析逻辑
        i = 0
        while i < len(words):
            word = words[i]
            
            # 检查是否是否定词
            is_negated = False
            if i > 0 and words[i-1] in self.negations:
                is_negated = True
            
            # 检查是否是程度副词
            intensifier = 1.0
            if i > 0 and words[i-1] in self.intensifiers:
                intensifier = self.intensifiers[words[i-1]]
            
            # 检查情感词
            if word in self.positive_words:
                score = self.positive_words[word] * intensifier
                if is_negated:
                    negative_score += score
                else:
                    positive_score += score
            elif word in self.negative_words:
                score = abs(self.negative_words[word]) * intensifier
                if is_negated:
                    positive_score += score
                else:
                    negative_score += score
            
            i += 1
        
        # 计算综合得分
        overall_score = (positive_score - negative_score) / max(1.0, len(words) / 10.0)
        
        # 确定情感类型
        if overall_score > 0.3:
            sentiment_type = 'positive'
        elif overall_score < -0.3:
            sentiment_type = 'negative'
        else:
            sentiment_type = 'neutral'
        
        return {
            'positive': positive_score,
            'negative': negative_score,
            'score': overall_score,
            'sentiment': sentiment_type
        }
    
    def extract_key_phrases(self, text: str, top_n: int = 5) -> List[Dict[str, Any]]:
        """提取关键短语"""
        if not text:
            return []
        
        # 分词并过滤停用词
        words = list(jieba.cut_for_search(text))
        
        # 简单的词频统计
        word_freq = defaultdict(int)
        for word in words:
            # 过滤短词和标点
            if len(word) > 1 and word.strip() and not word.isspace():
                word_freq[word] += 1
        
        # 按词频排序
        sorted_phrases = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        
        # 返回前N个短语
        return [{'phrase': phrase, 'frequency': freq} for phrase, freq in sorted_phrases[:top_n]]
    
    def calculate_semantic_similarity(self, text1: str, text2: str) -> float:
        """计算两个文本的语义相似度"""
        if not text1 or not text2:
            return 0.0
        
        # 如果有词向量模型，使用词向量计算相似度
        if self.word2vec_model:
            try:
                # 分词
                words1 = [word for word in jieba.cut(text1) if word.strip()]
                words2 = [word for word in jieba.cut(text2) if word.strip()]
                
                # 过滤掉不在词向量中的词
                words1 = [word for word in words1 if word in self.word2vec_model.wv]
                words2 = [word for word in words2 if word in self.word2vec_model.wv]
                
                if not words1 or not words2:
                    return 0.0
                
                # 计算文本向量（词向量的平均值）
                vec1 = np.mean([self.word2vec_model.wv[word] for word in words1], axis=0)
                vec2 = np.mean([self.word2vec_model.wv[word] for word in words2], axis=0)
                
                # 计算余弦相似度
                similarity = cosine_similarity([vec1], [vec2])[0][0]
                return float(similarity)
            except Exception as e:
                logger.error(f"使用词向量计算相似度失败: {e}")
        
        # 备用方案：使用TF-IDF计算相似度
        try:
            vectorizer = TfidfVectorizer(tokenizer=jieba.cut, token_pattern=None)
            tfidf_matrix = vectorizer.fit_transform([text1, text2])
            similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]
            return float(similarity)
        except Exception as e:
            logger.error(f"使用TF-IDF计算相似度失败: {e}")
            return 0.0
    
    def classify_topic(self, text: str) -> str:
        """对文本进行主题分类"""
        if not text:
            return 'unknown'
        
        # 分词
        words = set(word for word in jieba.cut(text) if word.strip())
        
        # 统计每个主题的匹配词数
        topic_scores = defaultdict(int)
        for topic, keywords in self.topic_keywords.items():
            topic_scores[topic] = len(words.intersection(keywords))
        
        # 找出得分最高的主题
        if not topic_scores:
            return 'unknown'
        
        max_topic = max(topic_scores.items(), key=lambda x: x[1])
        return max_topic[0] if max_topic[1] > 0 else 'unknown'
    
    def generate_text_vector(self, text: str) -> Optional[np.ndarray]:
        """生成文本的向量表示"""
        if not text or not self.word2vec_model:
            return None
        
        try:
            # 分词
            words = [word for word in jieba.cut(text) if word.strip()]
            # 过滤掉不在词向量中的词
            words = [word for word in words if word in self.word2vec_model.wv]
            
            if not words:
                return None
            
            # 计算文本向量（词向量的平均值）
            text_vector = np.mean([self.word2vec_model.wv[word] for word in words], axis=0)
            return text_vector
        except Exception as e:
            logger.error(f"生成文本向量失败: {e}")
            return None
    
    def train_word2vec_model(self, sentences: List[List[str]], vector_size: int = 100, window: int = 5, min_count: int = 1):
        """训练词向量模型"""
        try:
            self.word2vec_model = Word2Vec(sentences=sentences, vector_size=vector_size, window=window, min_count=min_count, workers=4)
            self.word_vector_size = vector_size
            
            # 保存模型
            model_path = os.path.join(os.path.dirname(__file__), 'data', 'word2vec.model')
            os.makedirs(os.path.dirname(model_path), exist_ok=True)
            self.word2vec_model.save(model_path)
            logger.info(f"成功训练并保存词向量模型，向量大小: {vector_size}")
            return True
        except Exception as e:
            logger.error(f"训练词向量模型失败: {e}")
            return False
    
    def detect_question_type(self, text: str) -> str:
        """检测问题类型"""
        if not text:
            return 'unknown'
        
        # 检查疑问词
        question_words = {
            'what': {'什么', '啥', '何', '何等', '哪些', '哪类'},
            'who': {'谁', '哪个', '哪些人', '哪位', '何人'},
            'when': {'何时', '什么时候', '何时', '哪天', '哪年', '几点', '何时'},
            'where': {'哪里', '何处', '何地', '哪儿', '什么地方'},
            'why': {'为什么', '为何', '何故', '原因', '为啥'},
            'how': {'如何', '怎么', '怎样', '怎么样', '如何做', '怎么做', '如何办'},
            'yes_no': {'吗', '么', '是否', '是不是', '对吗', '对么'}
        }
        
        # 检查结尾标点
        if text.endswith('?') or text.endswith('？'):
            for q_type, words in question_words.items():
                for word in words:
                    if word in text:
                        return q_type
            return 'open_ended'
        
        # 检查是否包含疑问词但没有问号
        for q_type, words in question_words.items():
            for word in words:
                if word in text:
                    return q_type
        
        return 'statement'
    
    def calculate_readability(self, text: str) -> float:
        """计算文本可读性（简化版）"""
        if not text:
            return 0.0
        
        # 统计字数
        char_count = len(text)
        if char_count == 0:
            return 0.0
        
        # 统计句子数（简单按句号、问号、感叹号分割）
        sentences = [s for s in re.split(r'[。！？!?]', text) if s.strip()]
        sentence_count = max(1, len(sentences))
        
        # 分词并统计词数
        words = list(jieba.cut(text))
        word_count = len(words)
        
        # 计算平均句子长度（字数）
        avg_sentence_length = char_count / sentence_count
        
        # 计算平均词长
        avg_word_length = char_count / word_count if word_count > 0 else 0
        
        # 计算可读性得分（简化模型）
        # 得分越高表示越容易理解
        readability_score = 100 - (avg_sentence_length * 0.5 + (10 - avg_word_length) * 5)
        
        # 限制在0-100范围内
        return max(0.0, min(100.0, readability_score))
    
    def query_knowledge_base(self, query: str) -> Optional[str]:
        """查询常识知识库"""
        if not query:
            return None
        
        # 分词
        query_words = jieba.cut_for_search(query)
        
        # 查找相关的常识
        matches = []
        for word in query_words:
            if len(word) > 1 and word in self.knowledge_index:
                matches.extend(self.knowledge_index[word])
        
        # 去重
        unique_matches = []
        seen = set()
        for domain, question, answer in matches:
            if question not in seen:
                seen.add(question)
                unique_matches.append((domain, question, answer))
        
        # 计算匹配度
        best_match = None
        best_score = 0
        
        for domain, question, answer in unique_matches:
            # 计算查询与常识问题的相似度
            similarity = self.calculate_semantic_similarity(query, question)
            if similarity > best_score:
                best_score = similarity
                best_match = answer
        
        # 如果匹配度足够高，返回答案
        if best_score > 0.6:
            return best_match
        
        return None
    
    def apply_logical_reasoning(self, premise: str, conclusion: str) -> float:
        """应用逻辑推理规则，评估前提到结论的逻辑合理性"""
        if not premise or not conclusion:
            return 0.0
        
        # 计算语义相似度
        similarity = self.calculate_semantic_similarity(premise, conclusion)
        
        # 检测逻辑关系
        logical_relations = self.detect_logical_relations(premise, conclusion)
        
        # 基于逻辑关系调整相似度得分
        if logical_relations:
            # 因果关系增强得分
            if '因果' in logical_relations:
                similarity *= 1.2
            # 转折关系可能降低得分
            elif '转折' in logical_relations:
                similarity *= 0.8
        
        return similarity
    
    def detect_logical_relations(self, text1: str, text2: str) -> List[str]:
        """检测两个文本之间的逻辑关系"""
        relations = []
        
        # 检查逻辑连接词
        for relation_type, connectives in self.logical_connectives.items():
            for connective in connectives:
                if connective in text1 or connective in text2:
                    relations.append(relation_type)
                    break
        
        return relations
    
    def enhance_reply_with_knowledge(self, reply: str, context: str) -> str:
        """在回复中融入常识知识"""
        if not reply or not context:
            return reply
        
        # 查询常识知识库
        knowledge_answer = self.query_knowledge_base(context)
        
        # 如果找到相关常识，将其融入回复
        if knowledge_answer:
            # 随机选择融入方式
            integration_methods = [
                f"{reply} 另外，{knowledge_answer}",
                f"{reply} 顺便说一下，{knowledge_answer}",
                f"{reply} 你知道吗？{knowledge_answer}",
                f"{knowledge_answer} 所以{reply}"
            ]
            return random.choice(integration_methods)
        
        return reply
    
    def generate_logical_explanation(self, topic: str) -> Optional[str]:
        """为话题生成逻辑解释"""
        if not topic:
            return None
        
        # 简单实现：基于话题类型生成解释
        topic_type = self.classify_topic(topic)
        
        explanations = {
            'technology': '这个话题涉及技术领域，通常需要考虑原理、应用和发展趋势等方面。',
            'entertainment': '这个话题属于娱乐范畴，主要关注人们的休闲活动和文化生活。',
            'daily_life': '这是日常生活相关的话题，与人们的日常行为和习惯密切相关。',
            'emotion': '这个话题涉及情感领域，反映了人们的内心感受和情绪状态。',
            'question': '这是一个问题类话题，需要提供清晰、准确的回答。'
        }
        
        return explanations.get(topic_type, '这是一个有趣的话题，值得深入探讨。')

# 导入必要的模块
import re