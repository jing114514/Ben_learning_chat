import time
import random
import sqlite3
from enhanced_learning import EnhancedTrainingSystem

class MockConfig:
    def __init__(self):
        self.model_version = "1.0"
        self.context_window_size = 10
        self.message_quality_threshold = 80
        self.reply_candidate_limit = 20
        self.recent_reply_window = 50
        self.query_cache_size = 100
        self.message_count_check_interval = 100
        self.prohibited_words = []
        self.positive_words = ["好", "棒", "优秀", "很好", "不错"]
        self.negative_words = ["差", "糟糕", "不好", "坏", "恶劣"]

def test_query_performance():
    """测试数据库查询性能"""
    config = MockConfig()
    learning_system = EnhancedTrainingSystem("./chat_data.db", config)
    
    # 测试不同类型的查询
    test_queries = [
        "你好，今天天气怎么样？",
        "能帮我解释一下机器学习的概念吗？",
        "我感到有些不开心，怎么办？",
        "谢谢，你真的很有帮助！",
        "你知道Python的list和tuple有什么区别吗？"
    ]
    
    user_ids = ["user_1", "user_2", "user_3"]
    
    print("=== 数据库查询性能测试 ===")
    
    # 测试首次查询（无缓存）
    total_time_first = 0
    for query in test_queries:
        user_id = random.choice(user_ids)
        start_time = time.time()
        result = learning_system.find_relevant_reply(query, user_id)
        end_time = time.time()
        elapsed = end_time - start_time
        total_time_first += elapsed
        print(f"查询: '{query[:30]}...'，耗时: {elapsed:.4f}秒")
    
    avg_first = total_time_first / len(test_queries)
    print(f"首次查询平均耗时: {avg_first:.4f}秒")
    
    # 测试缓存查询
    total_time_cache = 0
    for query in test_queries:
        user_id = random.choice(user_ids)
        start_time = time.time()
        result = learning_system.find_relevant_reply(query, user_id)
        end_time = time.time()
        elapsed = end_time - start_time
        total_time_cache += elapsed
        print(f"缓存查询: '{query[:30]}...'，耗时: {elapsed:.4f}秒")
    
    avg_cache = total_time_cache / len(test_queries)
    print(f"缓存查询平均耗时: {avg_cache:.4f}秒")
    
    # 计算缓存提升比例，避免除以零
    if avg_first > 0:
        improvement = ((avg_first - avg_cache) / avg_first) * 100
        print(f"缓存提升比例: {improvement:.2f}%")
    else:
        print("缓存提升比例: 无法计算（首次查询耗时为零）")

def test_repeat_calls_performance():
    """测试重复调用的性能"""
    config = MockConfig()
    learning_system = EnhancedTrainingSystem("./chat_data.db", config)
    
    test_query = "你好，今天天气怎么样？"
    user_id = "test_user"
    
    print("\n=== 重复调用性能测试 ===")
    
    # 模拟多次调用
    times = []
    for i in range(20):
        start_time = time.time()
        result = learning_system.find_relevant_reply(test_query, user_id)
        end_time = time.time()
        elapsed = end_time - start_time
        times.append(elapsed)
        print(f"第{i+1}次调用，耗时: {elapsed:.4f}秒")
    
    avg_time = sum(times) / len(times)
    min_time = min(times)
    max_time = max(times)
    print(f"平均耗时: {avg_time:.4f}秒")
    print(f"最快耗时: {min_time:.4f}秒")
    print(f"最慢耗时: {max_time:.4f}秒")

def test_content_quality_score():
    """测试内容质量评分函数的性能（分词优化）"""
    config = MockConfig()
    learning_system = EnhancedTrainingSystem("./chat_data.db", config)
    
    test_replies = [
        "这是一个简单的回复",
        "机器学习是人工智能的一个分支，它使计算机能够从数据中学习而无需明确编程。",
        "我理解你的感受，有时候我们都会遇到这样的情况。",
        "Python中的list是可变的，而tuple是不可变的，这是它们最主要的区别。",
        "今天的天气看起来很不错，阳光明媚，适合外出活动。",
        "自然语言处理是计算机科学与人工智能领域的一个重要分支，它研究如何使计算机能够理解、解释和生成人类语言。",
        "深度学习是机器学习的一个子集，它使用多层神经网络来模拟人类大脑的工作方式，从而实现更高级的模式识别和预测能力。",
        "数据结构是计算机存储、组织数据的方式，常见的数据结构包括数组、链表、栈、队列、树、图等，它们各自有不同的特点和应用场景。"
    ]
    
    print("\n=== 内容质量评分性能测试 ===")
    
    # 运行多次以获得更准确的结果
    runs = 10
    all_times = []
    
    for run in range(runs):
        run_times = []
        for reply in test_replies:
            start_time = time.time()
            score = learning_system._calculate_content_quality_score(reply)
            end_time = time.time()
            elapsed = end_time - start_time
            run_times.append(elapsed)
        all_times.extend(run_times)
    
    avg_time = sum(all_times) / len(all_times)
    min_time = min(all_times)
    max_time = max(all_times)
    
    # 只显示第一次运行的结果
    for i, reply in enumerate(test_replies):
        score = learning_system._calculate_content_quality_score(reply)
        print(f"评分: '{reply[:30]}...'，得分: {score:.2f}，耗时: {all_times[i]:.4f}秒")
    
    print(f"\n总运行次数: {runs}次，每次{len(test_replies)}个回复")
    print(f"平均耗时: {avg_time:.4f}秒")
    print(f"最快耗时: {min_time:.4f}秒")
    print(f"最慢耗时: {max_time:.4f}秒")

# 新增：测试批量数据处理性能
def test_batch_processing():
    """测试批量数据处理的性能"""
    config = MockConfig()
    learning_system = EnhancedTrainingSystem("./chat_data.db", config)
    
    # 生成大量测试数据
    batch_size = 100
    test_data = [
        {
            "user_id": f"user_{i}",
            "message": f"这是第{i}个测试消息，包含一些关键词如Python、机器学习、人工智能等。",
            "reply": f"这是第{i}个测试回复，针对用户的问题进行详细解答。",
            "quality_score": random.randint(70, 95),
            "sentiment": random.choice(["positive", "negative", "neutral"])
        }
        for i in range(batch_size)
    ]
    
    print("\n=== 批量数据处理性能测试 ===")
    
    # 测试批量添加训练数据
    start_time = time.time()
    for data in test_data:
        # add_training_data只接受两个参数：message和quality_score
        learning_system.add_training_data(
            data["message"],
            data["quality_score"]
        )
    end_time = time.time()
    elapsed = end_time - start_time
    
    print(f"批量添加{batch_size}条训练数据，耗时: {elapsed:.4f}秒")
    print(f"平均每条数据耗时: {elapsed / batch_size:.4f}秒")
    print(f"训练数据缓存大小: {len(learning_system.training_data_cache)}")

if __name__ == "__main__":
    try:
        test_query_performance()
        test_repeat_calls_performance()
        test_content_quality_score()
        test_batch_processing()
        print("\n=== 性能测试完成 ===")
    except Exception as e:
        print(f"测试过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
