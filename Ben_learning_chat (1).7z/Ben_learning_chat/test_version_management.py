import asyncio
import sys
import os
import json
from datetime import datetime

# 添加当前目录到Python路径
sys.path.append(os.path.abspath(os.path.dirname(__file__)))

# 直接导入类而不通过包导入，避免NoneBot初始化问题
import enhanced_learning
EnhancedTrainingSystem = enhanced_learning.EnhancedTrainingSystem

# 定义一个简单的配置类
class TestConfig:
    def __init__(self):
        self.vectorizer_params = {
            'ngram_range': (1, 2),
            'max_features': 5000,
            'min_df': 1,
            'max_df': 0.95
        }
        self.model_params = {
            'n_clusters': 10,
            'random_state': 42,
            'n_init': 10
        }
        self.training_params = {
            'max_iterations': 100,
            'early_stopping': True,
            'improvement_threshold': 0.01
        }
        self.model_version = "1.0.0"
        self.message_count_check_interval = 100
        self.message_quality_threshold = 0.7
        self.max_training_data_size = 1000
        self.context_window_size = 5
        self.cluster_distance_threshold = 0.5
        self.semantic_similarity_threshold = 0.6
        self.contextual_relevance_threshold = 0.6
        self.training_max_messages = 100
        self.training_min_improvement = 0.01
        self.training_iterations = 10
        self.cache_size_limit = 1000
        self.max_context_size = 10
        self.similarity_threshold = 0.5
        self.auto_tuning_enabled = False
        self.advanced_clustering_enabled = False
        self.context_analysis_enabled = False

# 测试模型版本管理功能
async def test_version_management():
    print("=== 测试模型版本管理功能 ===")
    
    # 创建临时数据库文件
    db_path = 'test_version_management.db'
    config = TestConfig()
    
    # 初始化训练系统
    system = EnhancedTrainingSystem(db_path, config)
    
    # 确保chat_logs表存在
    import sqlite3
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chat_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message TEXT NOT NULL,
                quality_score REAL NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        conn.commit()
    
    # 1. 测试初始版本信息
    print("\n1. 测试初始版本信息:")
    initial_version = system.config.model_version
    print(f"   初始版本: {initial_version}")
    print(f"   版本历史: {json.dumps(system.model_versions, indent=2, ensure_ascii=False)}")
    
    # 2. 测试添加训练数据
    print("\n2. 测试添加训练数据:")
    for i in range(10):
        message = f"测试消息 {i}"
        system.add_training_data(message, quality_score=0.8)
        system.increment_message_count()
    print(f"   添加了10条训练数据")
    print(f"   消息计数: {system.message_count_since_last_training}")
    
    # 手动将消息插入到chat_logs表中（因为add_training_data可能不直接插入）
    import sqlite3
    with sqlite3.connect(db_path) as conn:
        cursor = conn.cursor()
        for i in range(10):
            cursor.execute(
                "INSERT INTO chat_logs (message, quality_score) VALUES (?, ?)",
                (f"测试消息 {i}", 0.8)
            )
        conn.commit()
    print(f"   已将消息手动插入到chat_logs表中")
    
    # 3. 直接测试版本管理功能，不依赖训练过程
    print("\n3. 直接测试版本管理功能:")
    
    # 测试版本更新
    print("   测试版本更新:")
    initial_version = system.config.model_version
    system._update_model_version()
    new_version = system.config.model_version
    print(f"   从版本 {initial_version} 更新到 {new_version}")
    print(f"   版本历史: {json.dumps(system.model_versions, indent=2, ensure_ascii=False)}")
    
    # 测试再次更新版本
    print("\n   测试再次更新版本:")
    initial_version = new_version
    system._update_model_version()
    new_version = system.config.model_version
    print(f"   从版本 {initial_version} 更新到 {new_version}")
    print(f"   版本历史: {json.dumps(system.model_versions, indent=2, ensure_ascii=False)}")
    
    # 5. 测试获取模型信息
    print("\n5. 测试获取模型信息:")
    all_versions = system.get_all_versions()
    print(f"   所有版本: {len(all_versions)} 个")
    
    for version_info in all_versions:
        model_info = system.get_model_info(version=version_info['version'])
        print(f"   版本 {version_info['version']} 信息: {json.dumps(model_info, indent=2, ensure_ascii=False)}")
    
    # 6. 测试版本切换
    print("\n6. 测试版本切换:")
    if len(all_versions) > 1:
        old_version = all_versions[0]['version']
        print(f"   切换到旧版本: {old_version}")
        await system.switch_model_version(old_version)
        print(f"   当前版本: {system.config.model_version}")
        
        # 切回最新版本
        latest_version = all_versions[-1]['version']
        print(f"   切换回最新版本: {latest_version}")
        await system.switch_model_version(latest_version)
        print(f"   当前版本: {system.config.model_version}")
    
    # 7. 测试版本比较
    print("\n7. 测试版本比较:")
    if len(all_versions) > 1:
        version1 = all_versions[0]['version']
        version2 = all_versions[-1]['version']
        comparison = system.compare_versions(version1, version2)
        print(f"   版本 {version1} 与 {version2} 的比较: {json.dumps(comparison, indent=2, ensure_ascii=False)}")
    
    # 8. 测试清理旧版本
    print("\n8. 测试清理旧版本:")
    print(f"   清理前版本数量: {len(system.model_versions)}")
    await system.cleanup_old_versions(keep_latest=1)
    print(f"   清理后版本数量: {len(system.model_versions)}")
    print(f"   剩余版本: {json.dumps(system.model_versions, indent=2, ensure_ascii=False)}")
    
    # 清理临时数据库文件
    import os
    if os.path.exists(db_path):
        try:
            os.remove(db_path)
            print(f"   已清理临时数据库文件: {db_path}")
        except PermissionError:
            print(f"   警告: 无法删除临时数据库文件 {db_path}，可能仍有进程在使用它")
    
    print("\n=== 模型版本管理功能测试完成 ===")

if __name__ == "__main__":
    asyncio.run(test_version_management())
